﻿<!DOCTYPE html>
<html>
  <head>
    <title>Manage groups-Admin</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/manage_groups-admin/styles.css" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="resources/scripts/axure/axQuery.js"></script>
    <script src="resources/scripts/axure/globals.js"></script>
    <script src="resources/scripts/axutils.js"></script>
    <script src="resources/scripts/axure/annotation.js"></script>
    <script src="resources/scripts/axure/axQuery.std.js"></script>
    <script src="resources/scripts/axure/doc.js"></script>
    <script src="resources/scripts/messagecenter.js"></script>
    <script src="resources/scripts/axure/events.js"></script>
    <script src="resources/scripts/axure/recording.js"></script>
    <script src="resources/scripts/axure/action.js"></script>
    <script src="resources/scripts/axure/expr.js"></script>
    <script src="resources/scripts/axure/geometry.js"></script>
    <script src="resources/scripts/axure/flyout.js"></script>
    <script src="resources/scripts/axure/model.js"></script>
    <script src="resources/scripts/axure/repeater.js"></script>
    <script src="resources/scripts/axure/sto.js"></script>
    <script src="resources/scripts/axure/utils.temp.js"></script>
    <script src="resources/scripts/axure/variables.js"></script>
    <script src="resources/scripts/axure/drag.js"></script>
    <script src="resources/scripts/axure/move.js"></script>
    <script src="resources/scripts/axure/visibility.js"></script>
    <script src="resources/scripts/axure/style.js"></script>
    <script src="resources/scripts/axure/adaptive.js"></script>
    <script src="resources/scripts/axure/tree.js"></script>
    <script src="resources/scripts/axure/init.temp.js"></script>
    <script src="resources/scripts/axure/legacy.js"></script>
    <script src="resources/scripts/axure/viewer.js"></script>
    <script src="resources/scripts/axure/math.js"></script>
    <script src="resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="data/document.js"></script>
    <script src="files/manage_groups-admin/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
  </head>
  <body>
    <form method="post" action ="">
    <div id="base" class="">

      <!-- Unnamed (Rectangle) -->
      <div id="u300" class="ax_default box_1">
        <div id="u300_div" class=""></div>
        <div id="u300_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u301" class="ax_default image">
        <img id="u301_img" class="img " src="images/meetings-admin/u129.png"/>
        <div id="u301_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u302" class="ax_default paragraph">
        <div id="u302_div" class=""></div>
        <div id="u302_text" class="text ">
          <p><span>MANAGE GROUPS</span></p>
        </div>
      </div>

      <!-- Sign In Header (Rectangle) -->
      <div id="u303" class="ax_default heading_3" data-label="Sign In Header">
        <div id="u303_div" class=""></div>
        <div id="u303_text" class="text ">
          <p><span style="text-decoration:underline ;">Employee details: </span></p>
        </div>
      </div>

      <!-- Sign In Header (Rectangle) -->
      <div id="u304" class="ax_default heading_3" data-label="Sign In Header">
        <div id="u304_div" class=""></div>
        <div id="u304_text" class="text ">
          <p><span style="text-decoration:underline ;">Create a group:</span></p>
        </div>
      </div>

      <!-- group_name_input (Text Field) -->
      <div id="u305" class="ax_default text_field" data-label="group_name_input">
        <div id="u305_div" class=""></div>
        <input id="u305_input" type="text" name="u305_input" value="" class="u305_input"/>
      </div>

      <!-- Title Label (Rectangle) -->
      <div id="u306" class="ax_default label" data-label="Title Label">
        <div id="u306_div" class=""></div>
        <div id="u306_text" class="text ">
          <p><span>Group Name:</span></p>
        </div>
      </div>

      <!-- member1_input (Text Field) -->
      <div id="u307" class="ax_default text_field" data-label="member1_input">
        <div id="u307_div" class=""></div>
        <input id="u307_input" type="text" name="u307_input" value="" class="u307_input"/>
      </div>

      <!-- Title Label (Rectangle) -->
      <div id="u308" class="ax_default label" data-label="Title Label">
        <div id="u308_div" class=""></div>
        <div id="u308_text" class="text ">
          <p><span>Member 1:</span></p>
        </div>
      </div>

      <!-- member2_input (Text Field) -->
      <div id="u309" class="ax_default text_field" data-label="member2_input">
        <div id="u309_div" class=""></div>
        <input id="u309_input" type="text" name="u309_input" value="" class="u309_input"/>
      </div>

      <!-- Title Label (Rectangle) -->
      <div id="u310" class="ax_default label" data-label="Title Label">
        <div id="u310_div" class=""></div>
        <div id="u310_text" class="text ">
          <p><span>Member 2:</span></p>
        </div>
      </div>

      <!-- create_group_button (Rectangle) -->
      <div id="u311" class="ax_default button" data-label="create_group_button">
        <div id="u311_div" class=""></div>
        <div id="u311_text" class="text ">
          <input id="u311_text" type="submit" value="Create Group" style="background-color: #301B3F; color:white" class="u311_text"/>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u312" class="ax_default box_1">
        <div id="u312_div" class=""></div>
        <div id="u312_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u313" class="ax_default paragraph">
        <div id="u313_div" class=""></div>
        <div id="u313_text" class="text ">
          <p><span style="text-decoration:underline ;">PERSONAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u314" class="ax_default button">
        <div id="u314_div" class=""></div>
        <div id="u314_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Home</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u315" class="ax_default button">
        <div id="u315_div" class=""></div>
        <div id="u315_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Profile</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u316" class="ax_default button">
        <div id="u316_div" class=""></div>
        <div id="u316_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Meetings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u317" class="ax_default button">
        <div id="u317_div" class=""></div>
        <div id="u317_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Chat</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u318" class="ax_default paragraph">
        <div id="u318_div" class=""></div>
        <div id="u318_text" class="text ">
          <p><span style="text-decoration:underline ;">ADMIN</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u319" class="ax_default button">
        <div id="u319_div" class=""></div>
        <div id="u319_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; View Projects</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u320" class="ax_default button">
        <div id="u320_div" class=""></div>
        <div id="u320_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Manage Projects</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u321" class="ax_default button">
        <div id="u321_div" class=""></div>
        <div id="u321_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Announcements</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u322" class="ax_default button">
        <div id="u322_div" class=""></div>
        <div id="u322_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Manage Groups</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u323" class="ax_default paragraph">
        <div id="u323_div" class=""></div>
        <div id="u323_text" class="text ">
          <p><span style="text-decoration:underline ;">GENERAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u324" class="ax_default button">
        <div id="u324_div" class=""></div>
        <div id="u324_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Settings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u325" class="ax_default button">
        <div id="u325_div" class=""></div>
        <div id="u325_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Help</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u326" class="ax_default button">
        <div id="u326_div" class=""></div>
        <div id="u326_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; FAQs</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u327" class="ax_default button">
        <div id="u327_div" class=""></div>
        <div id="u327_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Manage Employees</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u328" class="ax_default button">
        <div id="u328_div" class=""></div>
        <div id="u328_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; View Employees</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u329" class="ax_default button">
        <div id="u329_div" class=""></div>
        <div id="u329_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; View Groups</span></p>
        </div>
      </div>

      <!-- Unnamed (Dynamic Panel) -->
      <div id="u330" class="ax_default">
        <div id="u330_state0" class="panel_state" data-label="State 1" style="">
          <div id="u330_state0_content" class="panel_state_content">

            <!-- Unnamed (Rectangle) -->
            <div id="u331" class="ax_default box_1">
              <div id="u331_div" class=""></div>
              <div id="u331_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Image) -->
            <div id="u332" class="ax_default image">
              <img id="u332_img" class="img " src="images/home_page/u3.png"/>
              <div id="u332_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u333" class="ax_default icon">
              <img id="u333_img" class="img " src="images/homepage-admin/u107.svg"/>
              <div id="u333_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u334" class="ax_default icon">
              <img id="u334_img" class="img " src="images/homepage-admin/u108.svg"/>
              <div id="u334_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u335" class="ax_default icon">
              <img id="u335_img" class="img " src="images/homepage-admin/u109.svg"/>
              <div id="u335_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script src="resources/scripts/axure/ios.js"></script>

    <?php
      $groupname = filter_input(INPUT_POST, 'u305_input');
      $member1 = filter_input(INPUT_POST, 'u307_input');
      $member2 = filter_input(INPUT_POST, 'u309_input');

      $host = "localhost";
      $dbusername = "root";
      $dbpassword = "";
      $dbname = "audace_db";
      // Create connection
      $conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);
      if (mysqli_connect_error()){
        echo "Not Connected to DB";
      die('Connect Error ('. mysqli_connect_errno() .') '
      . mysqli_connect_error());
      }
      else{
        
      $sql = "INSERT INTO groups (group_name,member_1,member_2)
      values ('$groupname','$member1','$member2')";
      if ($conn->query($sql)){
      
      }
      else{
      echo "Error: ". $sql ."
      ". $conn->error;
      }
      $conn->close();
      }
      ?>

      <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round|Open+Sans">
      <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
      <style type="text/css">
      .bs-example{
      
      margin-left: 450px;
      text-align: center;
      color:white;
      width:60%;
      height:200px;
      font-size:13px;

      }
      </style>
      <script type="text/javascript">
      $(document).ready(function(){
      $('[data-toggle="tooltip"]').tooltip();   
      });
      </script>
     
      
      <div class="bs-example">
      <div class="container">
      <div class="row">
      <div class="col-md-12">
      <div class="page-header clearfix">
      </div>
      

      <?php
       $host='localhost';
          $username='root';
          $password='';
          $dbname = "audace_db";
          $conn=mysqli_connect($host,$username,$password,$dbname);
          if(!$conn)
              {
                die('Could not Connect MySql Server:' .mysql_error());
              }
      $result = mysqli_query($conn,"SELECT full_name, email, phone_number, gender FROM user_profile");
      ?>
      <?php
      if (mysqli_num_rows($result) > 0) {
      ?>


      <table class='table table-bordered ' bgcolor= #E2BFDC style= "margin-top: 330px" >


      <tr style="color: white" tr bgcolor=#5A1843 >

      <td><b>Full Name</b></td>
      <td><b>Email<b></td>
      <td><b>Phone Number<b></td>
      <td><b>Gender<b></td>
      </tr>


      <?php
      $i=0;
      while($row = mysqli_fetch_array($result)) {
      ?>
      <tr>
      <td><?php echo $row["full_name"]; ?></td>
      <td><?php echo $row["email"]; ?></td>
      <td><?php echo $row["phone_number"]; ?></td>
      <td><?php echo $row["gender"]; ?></td>
      </tr>
      <?php
      $i++;
      }
      ?>
      </table>
      <?php
      }
      else{
      echo "No result found";
      }
      ?>

    </form>
  </body>
</html>
