﻿<!DOCTYPE html>
<html>
  <head>
    <title>Manage Projects-Admin</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/manage_projects-admin/styles.css" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="resources/scripts/axure/axQuery.js"></script>
    <script src="resources/scripts/axure/globals.js"></script>
    <script src="resources/scripts/axutils.js"></script>
    <script src="resources/scripts/axure/annotation.js"></script>
    <script src="resources/scripts/axure/axQuery.std.js"></script>
    <script src="resources/scripts/axure/doc.js"></script>
    <script src="resources/scripts/messagecenter.js"></script>
    <script src="resources/scripts/axure/events.js"></script>
    <script src="resources/scripts/axure/recording.js"></script>
    <script src="resources/scripts/axure/action.js"></script>
    <script src="resources/scripts/axure/expr.js"></script>
    <script src="resources/scripts/axure/geometry.js"></script>
    <script src="resources/scripts/axure/flyout.js"></script>
    <script src="resources/scripts/axure/model.js"></script>
    <script src="resources/scripts/axure/repeater.js"></script>
    <script src="resources/scripts/axure/sto.js"></script>
    <script src="resources/scripts/axure/utils.temp.js"></script>
    <script src="resources/scripts/axure/variables.js"></script>
    <script src="resources/scripts/axure/drag.js"></script>
    <script src="resources/scripts/axure/move.js"></script>
    <script src="resources/scripts/axure/visibility.js"></script>
    <script src="resources/scripts/axure/style.js"></script>
    <script src="resources/scripts/axure/adaptive.js"></script>
    <script src="resources/scripts/axure/tree.js"></script>
    <script src="resources/scripts/axure/init.temp.js"></script>
    <script src="resources/scripts/axure/legacy.js"></script>
    <script src="resources/scripts/axure/viewer.js"></script>
    <script src="resources/scripts/axure/math.js"></script>
    <script src="resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="data/document.js"></script>
    <script src="files/manage_projects-admin/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
  </head>
  <body>
    <form method="post" action ="">
    <div id="base" class="">

      <!-- Unnamed (Rectangle) -->
      <div id="u232" class="ax_default box_1">
        <div id="u232_div" class=""></div>
        <div id="u232_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u233" class="ax_default image">
        <img id="u233_img" class="img " src="images/meetings-admin/u129.png"/>
        <div id="u233_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u234" class="ax_default paragraph">
        <div id="u234_div" class=""></div>
        <div id="u234_text" class="text ">
          <p><span>PROJECT STATUS</span></p>
        </div>
      </div>

      <!-- project_status_input (Droplist) -->
      <div id="u235" class="ax_default droplist" data-label="project_status_input">
        <div id="u235_div" class=""></div>
        <select id="u235_input" name="u235_input" class="u235_input">
          <option class="u235_input_option" selected value="    --Select--">&nbsp;&nbsp;&nbsp; --Select--</option>
          <option class="u235_input_option" value="    Approved">&nbsp;&nbsp;&nbsp; Approved</option>
          <option class="u235_input_option" value="    Not Approved">&nbsp;&nbsp;&nbsp; Not Approved</option>
        </select>
      </div>

      <!-- project_update_button (Rectangle) -->
      <div id="u236" class="ax_default button" data-label="project_update_button">
        <div id="u236_div" class=""></div>
        <div id="u236_text" class="text ">
          <input id="u236_text" type="submit" value="Update"style="background-color: #8C1A65; color:white; font-size: x-large;" class="u236_text"/>
        </div>
      </div>

      <!-- project_name_input (Text Field) -->
      <div id="u237" class="ax_default text_field" data-label="project_name_input">
        <div id="u237_div" class=""></div>
        <input id="u237_input" type="text" name="u237_input" value="" class="u237_input"/>
      </div>

      <!-- Project_name Label (Rectangle) -->
      <div id="u238" class="ax_default label" data-label="Project_name Label">
        <div id="u238_div" class=""></div>
        <div id="u238_text" class="text ">
          <p><span>Project Name</span></p>
        </div>
      </div>

      <!-- Status Label (Rectangle) -->
      <div id="u239" class="ax_default label" data-label="Status Label">
        <div id="u239_div" class=""></div>
        <div id="u239_text" class="text ">
          <p><span>Status</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u240" class="ax_default box_1">
        <div id="u240_div" class=""></div>
        <div id="u240_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u241" class="ax_default paragraph">
        <div id="u241_div" class=""></div>
        <div id="u241_text" class="text ">
          <p><span style="text-decoration:underline ;">PERSONAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u242" class="ax_default button">
        <div id="u242_div" class=""></div>
        <div id="u242_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Home</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u243" class="ax_default button">
        <div id="u243_div" class=""></div>
        <div id="u243_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Profile</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u244" class="ax_default button">
        <div id="u244_div" class=""></div>
        <div id="u244_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Meetings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u245" class="ax_default button">
        <div id="u245_div" class=""></div>
        <div id="u245_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Chat</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u246" class="ax_default paragraph">
        <div id="u246_div" class=""></div>
        <div id="u246_text" class="text ">
          <p><span style="text-decoration:underline ;">ADMIN</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u247" class="ax_default button">
        <div id="u247_div" class=""></div>
        <div id="u247_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; View Projects</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u248" class="ax_default button">
        <div id="u248_div" class=""></div>
        <div id="u248_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Manage Projects</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u249" class="ax_default button">
        <div id="u249_div" class=""></div>
        <div id="u249_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Announcements</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u250" class="ax_default button">
        <div id="u250_div" class=""></div>
        <div id="u250_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Manage Groups</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u251" class="ax_default paragraph">
        <div id="u251_div" class=""></div>
        <div id="u251_text" class="text ">
          <p><span style="text-decoration:underline ;">GENERAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u252" class="ax_default button">
        <div id="u252_div" class=""></div>
        <div id="u252_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Settings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u253" class="ax_default button">
        <div id="u253_div" class=""></div>
        <div id="u253_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Help</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u254" class="ax_default button">
        <div id="u254_div" class=""></div>
        <div id="u254_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; FAQs</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u255" class="ax_default button">
        <div id="u255_div" class=""></div>
        <div id="u255_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Manage Employees</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u256" class="ax_default button">
        <div id="u256_div" class=""></div>
        <div id="u256_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; View Employees</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u257" class="ax_default button">
        <div id="u257_div" class=""></div>
        <div id="u257_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; View Groups</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u258" class="ax_default paragraph">
        <div id="u258_div" class=""></div>
        <div id="u258_text" class="text ">
          <p><span style="text-decoration:underline ;">Update project Status:</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u259" class="ax_default paragraph">
        <div id="u259_div" class=""></div>
        <div id="u259_text" class="text ">
          <p><span style="text-decoration:underline ;">Projects:</span></p>
        </div>
      </div>

      <!-- Unnamed (Dynamic Panel) -->
      <div id="u260" class="ax_default">
        <div id="u260_state0" class="panel_state" data-label="State 1" style="">
          <div id="u260_state0_content" class="panel_state_content">

            <!-- Unnamed (Rectangle) -->
            <div id="u261" class="ax_default box_1">
              <div id="u261_div" class=""></div>
              <div id="u261_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Image) -->
            <div id="u262" class="ax_default image">
              <img id="u262_img" class="img " src="images/home_page/u3.png"/>
              <div id="u262_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u263" class="ax_default icon">
              <img id="u263_img" class="img " src="images/homepage-admin/u107.svg"/>
              <div id="u263_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u264" class="ax_default icon">
              <img id="u264_img" class="img " src="images/homepage-admin/u108.svg"/>
              <div id="u264_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u265" class="ax_default icon">
              <img id="u265_img" class="img " src="images/homepage-admin/u109.svg"/>
              <div id="u265_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script src="resources/scripts/axure/ios.js"></script>

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round|Open+Sans">
      <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
      <style type="text/css">
      .bs-example{
      margin-top: 0px;
      margin-left: 370px;
      text-align: center;
      color:white;
      width:70%;
      height:500px;
      font-size:17px;

      }
      </style>
      <script type="text/javascript">
      $(document).ready(function(){
      $('[data-toggle="tooltip"]').tooltip();   
      });
      </script>
     
      
      <div class="bs-example">
      <div class="container">
      <div class="row">
      <div class="col-md-12">
      <div class="page-header clearfix">
     <!--  <h2 class="pull-left">Announcement List</h2> -->
      </div>
      

      <?php
       $host='localhost';
          $username='root';
          $password='';
          $dbname = "audace_db";
          $conn=mysqli_connect($host,$username,$password,$dbname);
          if(!$conn)
              {
                die('Could not Connect MySql Server:' .mysql_error());
              }
      $result = mysqli_query($conn,"SELECT * FROM projects");
      ?>
      <?php
      if (mysqli_num_rows($result) > 0) {
      ?>


      <table class='table table-bordered' bgcolor= #E2BFDC  style="margin-top: 350px;">


      <tr style="color: white" tr bgcolor=#5A1843>

      <td><b>Project Name</b></td>
      <td><b>File Name<b></td>
      <td><b>Status<b></td>
      </tr>


      <?php
      $i=0;
      while($row = mysqli_fetch_array($result)) {
      ?>
      <tr>
      <td><?php echo $row["project_name"]; ?></td>
      <td><?php echo $row["project_path"]; ?></td>
      <td><?php echo $row["status"]; ?></td>
      </tr>
      <?php
      $i++;
      }
      ?>
      </table>
      <?php
      }
      else{
      echo "No result found";
      }
      ?>


    <?php
      $name = filter_input(INPUT_POST, 'u237_input');
      $status = filter_input(INPUT_POST, 'u235_input');
      



      $host = "localhost";
      $dbusername = "root";
      $dbpassword = "";
      $dbname = "audace_db";
      // Create connection
      $conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);
      if (mysqli_connect_error()){
        echo "Not Connected to DB";
      die('Connect Error ('. mysqli_connect_errno() .') '
      . mysqli_connect_error());
      }
      else{
        
      $sql = "UPDATE `projects` SET `status`='$status' WHERE project_name='$name' ";
      if ($conn->query($sql)){
      
      }
      else{
      echo "Error: ". $sql ."
      ". $conn->error;
      }
      $conn->close();
      }
      ?>

    
  </form>
  </body>
</html>
