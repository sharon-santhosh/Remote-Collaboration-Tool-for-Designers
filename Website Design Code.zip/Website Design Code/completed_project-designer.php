﻿<!DOCTYPE html>
<html>
  <head>
    <title>Completed Project-Designer</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/completed_project-designer/styles.css" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="resources/scripts/axure/axQuery.js"></script>
    <script src="resources/scripts/axure/globals.js"></script>
    <script src="resources/scripts/axutils.js"></script>
    <script src="resources/scripts/axure/annotation.js"></script>
    <script src="resources/scripts/axure/axQuery.std.js"></script>
    <script src="resources/scripts/axure/doc.js"></script>
    <script src="resources/scripts/messagecenter.js"></script>
    <script src="resources/scripts/axure/events.js"></script>
    <script src="resources/scripts/axure/recording.js"></script>
    <script src="resources/scripts/axure/action.js"></script>
    <script src="resources/scripts/axure/expr.js"></script>
    <script src="resources/scripts/axure/geometry.js"></script>
    <script src="resources/scripts/axure/flyout.js"></script>
    <script src="resources/scripts/axure/model.js"></script>
    <script src="resources/scripts/axure/repeater.js"></script>
    <script src="resources/scripts/axure/sto.js"></script>
    <script src="resources/scripts/axure/utils.temp.js"></script>
    <script src="resources/scripts/axure/variables.js"></script>
    <script src="resources/scripts/axure/drag.js"></script>
    <script src="resources/scripts/axure/move.js"></script>
    <script src="resources/scripts/axure/visibility.js"></script>
    <script src="resources/scripts/axure/style.js"></script>
    <script src="resources/scripts/axure/adaptive.js"></script>
    <script src="resources/scripts/axure/tree.js"></script>
    <script src="resources/scripts/axure/init.temp.js"></script>
    <script src="resources/scripts/axure/legacy.js"></script>
    <script src="resources/scripts/axure/viewer.js"></script>
    <script src="resources/scripts/axure/math.js"></script>
    <script src="resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="data/document.js"></script>
    <script src="files/completed_project-designer/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
  </head>
  <body>
    <form method="post" action ="" enctype="multipart/form-data">
    <div id="base" class="">

      <!-- Unnamed (Rectangle) -->
      <div id="u677" class="ax_default box_1">
        <div id="u677_div" class=""></div>
        <div id="u677_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u678" class="ax_default image">
        <img id="u678_img" class="img " src="images/meetings-admin/u129.png"/>
        <div id="u678_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u679" class="ax_default paragraph">
        <div id="u679_div" class=""></div>
        <div id="u679_text" class="text ">
          <p><span>COMPLETED PROJECTS</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u680" class="ax_default paragraph">
        <div id="u680_div" class=""></div>
        <div id="u680_text" class="text ">
          <p><span style="text-decoration:underline ;">Project Status:</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u681" class="ax_default paragraph">
        <div id="u681_div" class=""></div>
        <div id="u681_text" class="text ">
          <p><span style="text-decoration:underline ;">Upload your projects:</span></p>
        </div>
      </div>

      <!-- project_name_input (Text Field) -->
      <div id="u682" class="ax_default text_field" data-label="project_name_input">
        <div id="u682_div" class=""></div>
        <input id="u682_input" type="text" name="project_name" value="" class="u682_input"/>
      </div>

      <!-- Project_name Label (Rectangle) -->
      <div id="u683" class="ax_default label" data-label="Project_name Label">
        <div id="u683_div" class=""></div>
        <div id="u683_text" class="text ">
          <p><span>Project Name</span></p>
        </div>
      </div>

      <!-- project_file_input (Text Field) -->
      <div id="u684" class="ax_default text_field" data-label="project_file_input">
        <div id="u684_div" class=""></div>
        <input id="u684_input" type="file" name="fileImg" value="" class="u684_input"/>
      </div>

      <!-- Project_name Label (Rectangle) -->
      <div id="u685" class="ax_default label" data-label="Project_name Label">
        <div id="u685_div" class=""></div>
        <div id="u685_text" class="text ">
          <p><span>Project File</span></p>
        </div>
      </div>

      <!-- project_upload_button (Shape) -->
      <div id="u686" class="ax_default button" data-label="project_upload_button">
        <img id="u686_img" class="img " src="images/completed_project-designer/project_upload_button_u686.svg"/>
        <div id="u686_text" class="text ">
          <input type="submit" name="btn_upload" value="Upload" style="background-color: #8C1A65; color:white" class="u686_text"/>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u687" class="ax_default box_1">
        <div id="u687_div" class=""></div>
        <div id="u687_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u688" class="ax_default paragraph">
        <div id="u688_div" class=""></div>
        <div id="u688_text" class="text ">
          <p><span style="text-decoration:underline ;">PERSONAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u689" class="ax_default button">
        <div id="u689_div" class=""></div>
        <div id="u689_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Home</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u690" class="ax_default button">
        <div id="u690_div" class=""></div>
        <div id="u690_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Profile</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u691" class="ax_default button">
        <div id="u691_div" class=""></div>
        <div id="u691_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Meetings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u692" class="ax_default button">
        <div id="u692_div" class=""></div>
        <div id="u692_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Chat</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u693" class="ax_default paragraph">
        <div id="u693_div" class=""></div>
        <div id="u693_text" class="text ">
          <p><span style="text-decoration:underline ;">TEAM</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u694" class="ax_default button">
        <div id="u694_div" class=""></div>
        <div id="u694_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Create a project</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u695" class="ax_default button">
        <div id="u695_div" class=""></div>
        <div id="u695_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Completed projects</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u696" class="ax_default button">
        <div id="u696_div" class=""></div>
        <div id="u696_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Announcements</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u697" class="ax_default button">
        <div id="u697_div" class=""></div>
        <div id="u697_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Groups</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u698" class="ax_default paragraph">
        <div id="u698_div" class=""></div>
        <div id="u698_text" class="text ">
          <p><span style="text-decoration:underline ;">GENERAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u699" class="ax_default button">
        <div id="u699_div" class=""></div>
        <div id="u699_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Settings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u700" class="ax_default button">
        <div id="u700_div" class=""></div>
        <div id="u700_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Help</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u701" class="ax_default button">
        <div id="u701_div" class=""></div>
        <div id="u701_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; FAQs</span></p>
        </div>
      </div>

      <!-- Unnamed (Dynamic Panel) -->
      <div id="u702" class="ax_default">
        <div id="u702_state0" class="panel_state" data-label="State 1" style="">
          <div id="u702_state0_content" class="panel_state_content">

            <!-- Unnamed (Rectangle) -->
            <div id="u703" class="ax_default box_1">
              <div id="u703_div" class=""></div>
              <div id="u703_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Image) -->
            <div id="u704" class="ax_default image">
              <img id="u704_img" class="img " src="images/home_page/u3.png"/>
              <div id="u704_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u705" class="ax_default icon">
              <img id="u705_img" class="img " src="images/homepage-admin/u107.svg"/>
              <div id="u705_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u706" class="ax_default icon">
              <img id="u706_img" class="img " src="images/homepage-admin/u108.svg"/>
              <div id="u706_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u707" class="ax_default icon">
              <img id="u707_img" class="img " src="images/homepage-admin/u109.svg"/>
              <div id="u707_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script src="resources/scripts/axure/ios.js"></script>

      <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round|Open+Sans">
      <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
      <style type="text/css">
      .bs-example{
      margin-top: 0px;
      margin-left: 370px;
      text-align: center;
      color:white;
      width:70%;
      height:500px;
      font-size:17px;

      }
      </style>
      <script type="text/javascript">
      $(document).ready(function(){
      $('[data-toggle="tooltip"]').tooltip();   
      });
      </script>
     
      
      <div class="bs-example">
      <div class="container">
      <div class="row">
      <div class="col-md-12">
      <div class="page-header clearfix">
     
      </div>
      

      <?php
       $host='localhost';
          $username='root';
          $password='';
          $dbname = "audace_db";
          $conn=mysqli_connect($host,$username,$password,$dbname);
          if(!$conn)
              {
                die('Could not Connect MySql Server:' .mysql_error());
              }
      $result = mysqli_query($conn,"SELECT * FROM projects");
      ?>
      <?php
      if (mysqli_num_rows($result) > 0) {
      ?>


      <table class='table table-bordered' bgcolor= #E2BFDC  style="margin-top: 350px;">


      <tr style="color: white" tr bgcolor=#5A1843>

      <td><b>Project Name</b></td>
      <td><b>File Name<b></td>
      <td><b>Status<b></td>
      </tr>


      <?php
      $i=0;
      while($row = mysqli_fetch_array($result)) {
      ?>
      <tr>
      <td><?php echo $row["project_name"]; ?></td>
      <td><?php echo $row["project_path"]; ?></td>
      <td><?php echo $row["status"]; ?></td>
      </tr>
      <?php
      $i++;
      }
      ?>
      </table>
      <?php
      }
      else{
      echo "No result found";
      }
      ?>

<?php  
// Database configuration  
$dbHost     = "localhost";  
$dbUsername = "root";  
$dbPassword = "";  
$dbName     = "audace_db";  
  
// Create database connection  
$db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);  
  
// Check connection  
if ($db->connect_error) {  
    die("Connection failed: " . $db->connect_error);  
}
 
 //$error = "";
if (isset($_POST["btn_upload"]) == "Upload")
  {
    $file_tmp = $_FILES["fileImg"]["tmp_name"];
    $file_name = $_FILES["fileImg"]["name"];

    /*image name variable that you will insert in database ---*/
    $image_name = $_POST["project_name"];

    //image directory where actual image will be store
    $file_path = "photo/".$file_name; 

  /*---------------- php textbox validation checking ------------------*/
  if($image_name == "")
  {
    $error = "Please enter Image name.";
  }

  /*-------- now insertion of image section has start -------------*/
  else
  {
    if(file_exists($file_path))
    {
      $error = "Sorry,The <b>".$file_name."</b> image already exist.";
    }
      else
      {
        $result = mysqli_connect($dbHost, $dbUsername,$dbPassword ) or die("Connection error: ". mysqli_error());
        mysqli_select_db($result, $dbName) or die("Could not Connect to Database: ". mysqli_error());
        mysqli_query($result,"INSERT INTO projects(project_name,project_path) VALUES('$image_name','$file_path')") or die ("Image not inserted". mysqli_error());
        move_uploaded_file($file_tmp,$file_path);
        $error = "<p align=center>File ".$_FILES["fileImg"]["name"].""."<br />Image saved into Table.";
      }
    }
  }
?>
  </body>
</html>
