﻿<!DOCTYPE html>
<html>
  <head>
    <title>Google Login</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/google_login/styles.css" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="resources/scripts/axure/axQuery.js"></script>
    <script src="resources/scripts/axure/globals.js"></script>
    <script src="resources/scripts/axutils.js"></script>
    <script src="resources/scripts/axure/annotation.js"></script>
    <script src="resources/scripts/axure/axQuery.std.js"></script>
    <script src="resources/scripts/axure/doc.js"></script>
    <script src="resources/scripts/messagecenter.js"></script>
    <script src="resources/scripts/axure/events.js"></script>
    <script src="resources/scripts/axure/recording.js"></script>
    <script src="resources/scripts/axure/action.js"></script>
    <script src="resources/scripts/axure/expr.js"></script>
    <script src="resources/scripts/axure/geometry.js"></script>
    <script src="resources/scripts/axure/flyout.js"></script>
    <script src="resources/scripts/axure/model.js"></script>
    <script src="resources/scripts/axure/repeater.js"></script>
    <script src="resources/scripts/axure/sto.js"></script>
    <script src="resources/scripts/axure/utils.temp.js"></script>
    <script src="resources/scripts/axure/variables.js"></script>
    <script src="resources/scripts/axure/drag.js"></script>
    <script src="resources/scripts/axure/move.js"></script>
    <script src="resources/scripts/axure/visibility.js"></script>
    <script src="resources/scripts/axure/style.js"></script>
    <script src="resources/scripts/axure/adaptive.js"></script>
    <script src="resources/scripts/axure/tree.js"></script>
    <script src="resources/scripts/axure/init.temp.js"></script>
    <script src="resources/scripts/axure/legacy.js"></script>
    <script src="resources/scripts/axure/viewer.js"></script>
    <script src="resources/scripts/axure/math.js"></script>
    <script src="resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="data/document.js"></script>
    <script src="files/google_login/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">

      <!-- Unnamed (Rectangle) -->
      <div id="u42" class="ax_default box_1">
        <div id="u42_div" class=""></div>
        <div id="u42_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u43" class="ax_default box_1">
        <div id="u43_div" class=""></div>
        <div id="u43_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u44" class="ax_default image">
        <img id="u44_img" class="img " src="images/google_login/u44.png"/>
        <div id="u44_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u45" class="ax_default heading_1">
        <div id="u45_div" class=""></div>
        <div id="u45_text" class="text ">
          <p><span>Sign in</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u46" class="ax_default heading_2">
        <div id="u46_div" class=""></div>
        <div id="u46_text" class="text ">
          <p><span>to continue with Gmail</span></p>
        </div>
      </div>

      <!-- email (Text Field) -->
      <div id="u47" class="ax_default text_field" data-label="email">
        <div id="u47_div" class=""></div>
        <input id="u47_input" type="text" value="" class="u47_input"/>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u48" class="ax_default paragraph">
        <div id="u48_div" class=""></div>
        <div id="u48_text" class="text ">
          <p><span>Email or phone</span></p>
        </div>
      </div>

      <!-- password (Text Field) -->
      <div id="u49" class="ax_default text_field" data-label="password">
        <div id="u49_div" class=""></div>
        <input id="u49_input" type="text" value="" class="u49_input"/>
      </div>

      <!-- Unnamed (Shape) -->
      <div id="u50" class="ax_default paragraph">
        <img id="u50_img" class="img " src="images/google_login/u50.svg"/>
        <div id="u50_text" class="text ">
          <p><span>Password</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u51" class="ax_default link_button">
        <div id="u51_div" class=""></div>
        <div id="u51_text" class="text ">
          <p><span>Need Help?</span></p>
        </div>
      </div>

      <!-- Unnamed (Checkbox) -->
      <div id="u52" class="ax_default checkbox1">
        <label id="u52_input_label" for="u52_input" style="position: absolute; left: 0px;">
          <img id="u52_img" class="img " src="images/google_login/u52.svg"/>
          <div id="u52_text" class="text ">
            <p><span>&nbsp; Remember Me</span></p>
          </div>
        </label>
        <input id="u52_input" type="checkbox" value="checkbox"/>
      </div>

      <!-- Unnamed (Shape) -->
      <div id="u53" class="ax_default icon">
        <img id="u53_img" class="img " src="images/login_page/u41.svg"/>
        <div id="u53_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Sign In Button (Rectangle) -->
      <div id="u54" class="ax_default primary_button1" data-label="Sign In Button">
        <div id="u54_div" class=""></div>
        <div id="u54_text" class="text ">
          <p><span>Sign In</span></p>
        </div>
      </div>
    </div>
    <script src="resources/scripts/axure/ios.js"></script>
  </body>
</html>
