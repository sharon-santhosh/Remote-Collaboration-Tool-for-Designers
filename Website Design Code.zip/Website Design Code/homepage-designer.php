﻿<!DOCTYPE html>
<html>
  <head>
    <title>Homepage-Designer</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/homepage-designer/styles.css" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="resources/scripts/axure/axQuery.js"></script>
    <script src="resources/scripts/axure/globals.js"></script>
    <script src="resources/scripts/axutils.js"></script>
    <script src="resources/scripts/axure/annotation.js"></script>
    <script src="resources/scripts/axure/axQuery.std.js"></script>
    <script src="resources/scripts/axure/doc.js"></script>
    <script src="resources/scripts/messagecenter.js"></script>
    <script src="resources/scripts/axure/events.js"></script>
    <script src="resources/scripts/axure/recording.js"></script>
    <script src="resources/scripts/axure/action.js"></script>
    <script src="resources/scripts/axure/expr.js"></script>
    <script src="resources/scripts/axure/geometry.js"></script>
    <script src="resources/scripts/axure/flyout.js"></script>
    <script src="resources/scripts/axure/model.js"></script>
    <script src="resources/scripts/axure/repeater.js"></script>
    <script src="resources/scripts/axure/sto.js"></script>
    <script src="resources/scripts/axure/utils.temp.js"></script>
    <script src="resources/scripts/axure/variables.js"></script>
    <script src="resources/scripts/axure/drag.js"></script>
    <script src="resources/scripts/axure/move.js"></script>
    <script src="resources/scripts/axure/visibility.js"></script>
    <script src="resources/scripts/axure/style.js"></script>
    <script src="resources/scripts/axure/adaptive.js"></script>
    <script src="resources/scripts/axure/tree.js"></script>
    <script src="resources/scripts/axure/init.temp.js"></script>
    <script src="resources/scripts/axure/legacy.js"></script>
    <script src="resources/scripts/axure/viewer.js"></script>
    <script src="resources/scripts/axure/math.js"></script>
    <script src="resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="data/document.js"></script>
    <script src="files/homepage-designer/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">

      <!-- Unnamed (Rectangle) -->
      <div id="u509" class="ax_default box_1">
        <div id="u509_div" class=""></div>
        <div id="u509_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u510" class="ax_default box_2">
        <div id="u510_div" class=""></div>
        <div id="u510_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u511" class="ax_default box_2">
        <div id="u511_div" class=""></div>
        <div id="u511_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u512" class="ax_default box_2">
        <div id="u512_div" class=""></div>
        <div id="u512_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u513" class="ax_default box_2">
        <div id="u513_div" class=""></div>
        <div id="u513_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u514" class="ax_default image">
        <img id="u514_img" class="img " src="images/homepage-admin/u94.png"/>
        <div id="u514_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u515" class="ax_default paragraph">
        <div id="u515_div" class=""></div>
        <div id="u515_text" class="text ">
          <p><span>Create a new project and work on it with your team mates.</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u516" class="ax_default button">
        <div id="u516_div" class=""></div>
        <div id="u516_text" class="text ">
          <p><span>Create a project</span></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u517" class="ax_default image">
        <img id="u517_img" class="img " src="images/homepage-admin/u97.png"/>
        <div id="u517_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u518" class="ax_default image">
        <img id="u518_img" class="img " src="images/homepage-admin/u98.png"/>
        <div id="u518_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u519" class="ax_default paragraph">
        <div id="u519_div" class=""></div>
        <div id="u519_text" class="text ">
          <p><span>Connect efficiently with your team mates.</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u520" class="ax_default button">
        <div id="u520_div" class=""></div>
        <div id="u520_text" class="text ">
          <p><span>Groups</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u521" class="ax_default box_2">
        <div id="u521_div" class=""></div>
        <div id="u521_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u522" class="ax_default image">
        <img id="u522_img" class="img " src="images/homepage-admin/u102.svg"/>
        <div id="u522_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u523" class="ax_default paragraph">
        <div id="u523_div" class=""></div>
        <div id="u523_text" class="text ">
          <p><span>WELCOME TO AUDACE !</span></p>
        </div>
      </div>

      <!-- Unnamed (Dynamic Panel) -->
      <div id="u524" class="ax_default">
        <div id="u524_state0" class="panel_state" data-label="State 1" style="">
          <div id="u524_state0_content" class="panel_state_content">

            <!-- Unnamed (Rectangle) -->
            <div id="u525" class="ax_default box_1">
              <div id="u525_div" class=""></div>
              <div id="u525_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Image) -->
            <div id="u526" class="ax_default image">
              <img id="u526_img" class="img " src="images/home_page/u3.png"/>
              <div id="u526_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u527" class="ax_default icon">
              <img id="u527_img" class="img " src="images/homepage-admin/u107.svg"/>
              <div id="u527_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u528" class="ax_default icon">
              <img id="u528_img" class="img " src="images/homepage-admin/u108.svg"/>
              <div id="u528_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u529" class="ax_default icon">
              <img id="u529_img" class="img " src="images/homepage-admin/u109.svg"/>
              <div id="u529_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u530" class="ax_default box_1">
        <div id="u530_div" class=""></div>
        <div id="u530_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u531" class="ax_default paragraph">
        <div id="u531_div" class=""></div>
        <div id="u531_text" class="text ">
          <p><span style="text-decoration:underline ;">PERSONAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u532" class="ax_default button">
        <div id="u532_div" class=""></div>
        <div id="u532_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Home</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u533" class="ax_default button">
        <div id="u533_div" class=""></div>
        <div id="u533_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Profile</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u534" class="ax_default button">
        <div id="u534_div" class=""></div>
        <div id="u534_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Meetings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u535" class="ax_default button">
        <div id="u535_div" class=""></div>
        <div id="u535_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Chat</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u536" class="ax_default paragraph">
        <div id="u536_div" class=""></div>
        <div id="u536_text" class="text ">
          <p><span style="text-decoration:underline ;">TEAM</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u537" class="ax_default button">
        <div id="u537_div" class=""></div>
        <div id="u537_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Create a project</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u538" class="ax_default button">
        <div id="u538_div" class=""></div>
        <div id="u538_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Completed projects</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u539" class="ax_default button">
        <div id="u539_div" class=""></div>
        <div id="u539_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Announcements</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u540" class="ax_default button">
        <div id="u540_div" class=""></div>
        <div id="u540_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Groups</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u541" class="ax_default paragraph">
        <div id="u541_div" class=""></div>
        <div id="u541_text" class="text ">
          <p><span style="text-decoration:underline ;">GENERAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u542" class="ax_default button">
        <div id="u542_div" class=""></div>
        <div id="u542_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Settings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u543" class="ax_default button">
        <div id="u543_div" class=""></div>
        <div id="u543_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Help</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u544" class="ax_default button">
        <div id="u544_div" class=""></div>
        <div id="u544_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; FAQs</span></p>
        </div>
      </div>
    </div>
    <script src="resources/scripts/axure/ios.js"></script>
  </body>
</html>
