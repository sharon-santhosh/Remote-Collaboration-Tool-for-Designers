﻿<!DOCTYPE html>
<html>
  <head>
    <title>Edit Announcements-Admin</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/edit_announcements-admin/styles.css" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="resources/scripts/axure/axQuery.js"></script>
    <script src="resources/scripts/axure/globals.js"></script>
    <script src="resources/scripts/axutils.js"></script>
    <script src="resources/scripts/axure/annotation.js"></script>
    <script src="resources/scripts/axure/axQuery.std.js"></script>
    <script src="resources/scripts/axure/doc.js"></script>
    <script src="resources/scripts/messagecenter.js"></script>
    <script src="resources/scripts/axure/events.js"></script>
    <script src="resources/scripts/axure/recording.js"></script>
    <script src="resources/scripts/axure/action.js"></script>
    <script src="resources/scripts/axure/expr.js"></script>
    <script src="resources/scripts/axure/geometry.js"></script>
    <script src="resources/scripts/axure/flyout.js"></script>
    <script src="resources/scripts/axure/model.js"></script>
    <script src="resources/scripts/axure/repeater.js"></script>
    <script src="resources/scripts/axure/sto.js"></script>
    <script src="resources/scripts/axure/utils.temp.js"></script>
    <script src="resources/scripts/axure/variables.js"></script>
    <script src="resources/scripts/axure/drag.js"></script>
    <script src="resources/scripts/axure/move.js"></script>
    <script src="resources/scripts/axure/visibility.js"></script>
    <script src="resources/scripts/axure/style.js"></script>
    <script src="resources/scripts/axure/adaptive.js"></script>
    <script src="resources/scripts/axure/tree.js"></script>
    <script src="resources/scripts/axure/init.temp.js"></script>
    <script src="resources/scripts/axure/legacy.js"></script>
    <script src="resources/scripts/axure/viewer.js"></script>
    <script src="resources/scripts/axure/math.js"></script>
    <script src="resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="data/document.js"></script>
    <script src="files/edit_announcements-admin/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
  </head>
  <body>
    <form method="post" action ="">
    <div id="base" class="">

      <!-- Unnamed (Rectangle) -->
      <div id="u266" class="ax_default box_1">
        <div id="u266_div" class=""></div>
        <div id="u266_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u267" class="ax_default image">
        <img id="u267_img" class="img " src="images/meetings-admin/u129.png"/>
        <div id="u267_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u268" class="ax_default paragraph">
        <div id="u268_div" class=""></div>
        <div id="u268_text" class="text ">
          <p><span>ANNOUNCEMENTS</span></p>
        </div>
      </div>

      <!-- announcement_post_button (Rectangle) -->
      <div id="u269" class="ax_default button" data-label="announcement_post_button">
        <div id="u269_div" class=""></div>
        <div id="u269_text" class="text ">
          <input id="u269_text" type="submit" value="Post" style="background-color: #301B3F; color:white" class="u269_text"/>
        </div>
      </div>

      <!-- announcement_title_input (Text Field) -->
      <div id="u270" class="ax_default text_field" data-label="announcement_title_input">
        <div id="u270_div" class=""></div>
        <input id="u270_input" type="text" name="u270_input" value="" class="u270_input"/>
      </div>

      <!-- Title Label (Rectangle) -->
      <div id="u271" class="ax_default label" data-label="Title Label">
        <div id="u271_div" class=""></div>
        <div id="u271_text" class="text ">
          <p><span>Title</span></p>
        </div>
      </div>

      <!-- Description Label (Rectangle) -->
      <div id="u272" class="ax_default label" data-label="Description Label">
        <div id="u272_div" class=""></div>
        <div id="u272_text" class="text ">
          <p><span>Description</span></p>
        </div>
      </div>

      <!-- announcement_title_input (Text Field) -->
      <div id="u273" class="ax_default text_field" data-label="announcement_title_input">
        <div id="u273_div" class=""></div>
        <input id="u273_input" type="text" name="u273_input" value="" class="u273_input"/>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u274" class="ax_default paragraph">
        <div id="u274_div" class=""></div>
        <div id="u274_text" class="text ">
          <p><span style="text-decoration:underline ;">Add a new announcement:</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u275" class="ax_default paragraph">
        <div id="u275_div" class=""></div>
        <div id="u275_text" class="text ">
          <p><span style="text-decoration:underline ;">View announcements:</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u276" class="ax_default box_1">
        <div id="u276_div" class=""></div>
        <div id="u276_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u277" class="ax_default paragraph">
        <div id="u277_div" class=""></div>
        <div id="u277_text" class="text ">
          <p><span style="text-decoration:underline ;">PERSONAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u278" class="ax_default button">
        <div id="u278_div" class=""></div>
        <div id="u278_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Home</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u279" class="ax_default button">
        <div id="u279_div" class=""></div>
        <div id="u279_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Profile</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u280" class="ax_default button">
        <div id="u280_div" class=""></div>
        <div id="u280_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Meetings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u281" class="ax_default button">
        <div id="u281_div" class=""></div>
        <div id="u281_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Chat</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u282" class="ax_default paragraph">
        <div id="u282_div" class=""></div>
        <div id="u282_text" class="text ">
          <p><span style="text-decoration:underline ;">ADMIN</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u283" class="ax_default button">
        <div id="u283_div" class=""></div>
        <div id="u283_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; View Projects</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u284" class="ax_default button">
        <div id="u284_div" class=""></div>
        <div id="u284_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Manage Projects</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u285" class="ax_default button">
        <div id="u285_div" class=""></div>
        <div id="u285_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Announcements</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u286" class="ax_default button">
        <div id="u286_div" class=""></div>
        <div id="u286_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Manage Groups</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u287" class="ax_default paragraph">
        <div id="u287_div" class=""></div>
        <div id="u287_text" class="text ">
          <p><span style="text-decoration:underline ;">GENERAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u288" class="ax_default button">
        <div id="u288_div" class=""></div>
        <div id="u288_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Settings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u289" class="ax_default button">
        <div id="u289_div" class=""></div>
        <div id="u289_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Help</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u290" class="ax_default button">
        <div id="u290_div" class=""></div>
        <div id="u290_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; FAQs</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u291" class="ax_default button">
        <div id="u291_div" class=""></div>
        <div id="u291_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Manage Employees</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u292" class="ax_default button">
        <div id="u292_div" class=""></div>
        <div id="u292_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; View Employees</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u293" class="ax_default button">
        <div id="u293_div" class=""></div>
        <div id="u293_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; View Groups</span></p>
        </div>
      </div>

      <!-- Unnamed (Dynamic Panel) -->
      <div id="u294" class="ax_default">
        <div id="u294_state0" class="panel_state" data-label="State 1" style="">
          <div id="u294_state0_content" class="panel_state_content">

            <!-- Unnamed (Rectangle) -->
            <div id="u295" class="ax_default box_1">
              <div id="u295_div" class=""></div>
              <div id="u295_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Image) -->
            <div id="u296" class="ax_default image">
              <img id="u296_img" class="img " src="images/home_page/u3.png"/>
              <div id="u296_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u297" class="ax_default icon">
              <img id="u297_img" class="img " src="images/homepage-admin/u107.svg"/>
              <div id="u297_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u298" class="ax_default icon">
              <img id="u298_img" class="img " src="images/homepage-admin/u108.svg"/>
              <div id="u298_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u299" class="ax_default icon">
              <img id="u299_img" class="img " src="images/homepage-admin/u109.svg"/>
              <div id="u299_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script src="resources/scripts/axure/ios.js"></script>

    <?php
      $title = filter_input(INPUT_POST, 'u270_input');
      $desc = filter_input(INPUT_POST, 'u273_input');

      $host = "localhost";
      $dbusername = "root";
      $dbpassword = "";
      $dbname = "audace_db";
      // Create connection
      $conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);
      if (mysqli_connect_error()){
        echo "Not Connected to DB";
      die('Connect Error ('. mysqli_connect_errno() .') '
      . mysqli_connect_error());
      }
      else{
        
      $sql = "INSERT INTO announcements (title,description)
      values ('$title','$desc')";
      if ($conn->query($sql)){
      
      }
      else{
      echo "Error: ". $sql ."
      ". $conn->error;
      }
      $conn->close();
      }
      ?>

      <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round|Open+Sans">
      <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
      <style type="text/css">
      .bs-example{
      
      margin-left: 450px;
      text-align: center;
      color:white;
      width:60%;
      height:200px;
      font-size:17px;

      }
      </style>
      <script type="text/javascript">
      $(document).ready(function(){
      $('[data-toggle="tooltip"]').tooltip();   
      });
      </script>
     
      
      <div class="bs-example">
      <div class="container">
      <div class="row">
      <div class="col-md-12">
      <div class="page-header clearfix">
      <!-- <h2 class="pull-left">Announcement List</h2> -->
      </div>
      

      <?php
       $host='localhost';
          $username='root';
          $password='';
          $dbname = "audace_db";
          $conn=mysqli_connect($host,$username,$password,$dbname);
          if(!$conn)
              {
                die('Could not Connect MySql Server:' .mysql_error());
              }
      $result = mysqli_query($conn,"SELECT * FROM announcements");
      ?>
      <?php
      if (mysqli_num_rows($result) > 0) {
      ?>


      <table class='table table-bordered ' bgcolor= #E2BFDC style= "margin-top: 330px" >


      <tr style="color: white" tr bgcolor=#5A1843 >

      <td><b>Title</b></td>
      <td><b>Description<b></td>
      </tr>


      <?php
      $i=0;
      while($row = mysqli_fetch_array($result)) {
      ?>
      <tr>
      <td><?php echo $row["title"]; ?></td>
      <td><?php echo $row["description"]; ?></td>
      </tr>
      <?php
      $i++;
      }
      ?>
      </table>
      <?php
      }
      else{
      echo "No result found";
      }
      ?>

  </form>
  </body>
</html>
