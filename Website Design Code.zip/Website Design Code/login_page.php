﻿<!DOCTYPE html>
<html>
  <head>
    <title>Login Page</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/login_page/styles.css" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="resources/scripts/axure/axQuery.js"></script>
    <script src="resources/scripts/axure/globals.js"></script>
    <script src="resources/scripts/axutils.js"></script>
    <script src="resources/scripts/axure/annotation.js"></script>
    <script src="resources/scripts/axure/axQuery.std.js"></script>
    <script src="resources/scripts/axure/doc.js"></script>
    <script src="resources/scripts/messagecenter.js"></script>
    <script src="resources/scripts/axure/events.js"></script>
    <script src="resources/scripts/axure/recording.js"></script>
    <script src="resources/scripts/axure/action.js"></script>
    <script src="resources/scripts/axure/expr.js"></script>
    <script src="resources/scripts/axure/geometry.js"></script>
    <script src="resources/scripts/axure/flyout.js"></script>
    <script src="resources/scripts/axure/model.js"></script>
    <script src="resources/scripts/axure/repeater.js"></script>
    <script src="resources/scripts/axure/sto.js"></script>
    <script src="resources/scripts/axure/utils.temp.js"></script>
    <script src="resources/scripts/axure/variables.js"></script>
    <script src="resources/scripts/axure/drag.js"></script>
    <script src="resources/scripts/axure/move.js"></script>
    <script src="resources/scripts/axure/visibility.js"></script>
    <script src="resources/scripts/axure/style.js"></script>
    <script src="resources/scripts/axure/adaptive.js"></script>
    <script src="resources/scripts/axure/tree.js"></script>
    <script src="resources/scripts/axure/init.temp.js"></script>
    <script src="resources/scripts/axure/legacy.js"></script>
    <script src="resources/scripts/axure/viewer.js"></script>
    <script src="resources/scripts/axure/math.js"></script>
    <script src="resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="data/document.js"></script>
    <script src="files/login_page/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
  </head>
  <body>
    <form method="post" action ="">
    <div id="base" class="">

      <!-- Unnamed (Rectangle) -->
      <div id="u17" class="ax_default box_2">
        <div id="u17_div" class=""></div>
        <div id="u17_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Form Popup (Dynamic Panel) -->
      <div id="u18" class="ax_default" data-label="Form Popup">
        <div id="u18_state0" class="panel_state" data-label="Sign In " style="">
          <div id="u18_state0_content" class="panel_state_content">

            <!-- Sign In (Group) -->
            <div id="u19" class="ax_default" data-label="Sign In" data-left="142" data-top="45" data-width="378" data-height="496">

              <!-- Email Input (Text Field) -->
              <div id="u20" class="ax_default text_field" data-label="Email Input">
                <div id="u20_div" class=""></div>
                <input id="u20_input" type="email" name="u20_input" value="" class="u20_input"/>
              </div>

              <!-- Email Label (Rectangle) -->
              <div id="u21" class="ax_default label" data-label="Email Label">
                <div id="u21_div" class=""></div>
                <div id="u21_text" class="text ">
                  <p><span>Email </span></p>
                </div>
              </div>

              <!-- Email Error Message (Rectangle) -->
              <div id="u22" class="ax_default label ax_default_hidden" data-label="Email Error Message" style="display:none; visibility: hidden">
                <div id="u22_div" class=""></div>
                <div id="u22_text" class="text ">
                  <p><span>Please enter a valid email address</span></p>
                </div>
              </div>

              <!-- Sign In Header (Rectangle) -->
              <div id="u23" class="ax_default heading_3" data-label="Sign In Header">
                <div id="u23_div" class=""></div>
                <div id="u23_text" class="text ">
                  <p><span>Sign In </span></p>
                </div>
              </div>

              <!-- Password Label (Rectangle) -->
              <div id="u24" class="ax_default label" data-label="Password Label">
                <div id="u24_div" class=""></div>
                <div id="u24_text" class="text ">
                  <p><span>Password</span></p>
                </div>
              </div>

              <!-- Password Input (Text Field) -->
              <div id="u25" class="ax_default text_field" data-label="Password Input">
                <div id="u25_div" class=""></div>
                <input id="u25_input" type="password" name="u25_input" value="" class="u25_input"/>
              </div>

              <!-- Password Error Message (Rectangle) -->
              <div id="u26" class="ax_default label ax_default_hidden" data-label="Password Error Message" style="display:none; visibility: hidden">
                <div id="u26_div" class=""></div>
                <div id="u26_text" class="text ">
                  <p><span>Incorrect password</span></p>
                </div>
              </div>

              <!-- remember_me_box (Checkbox) -->
              <div id="u27" class="ax_default checkbox" data-label="remember_me_box">
                <label id="u27_input_label" for="u27_input" style="position: absolute; left: 0px;">
                  <img id="u27_img" class="img " src="images/login_page/remember_me_box_u27.svg"/>
                  <div id="u27_text" class="text ">
                    <p><span>Remember Me</span></p>
                  </div>
                </label>
                <input id="u27_input" type="checkbox" value="checkbox"/>
              </div>

              <!-- Sign In Button (Group) -->
              <div id="u28" class="ax_default" data-label="Sign In Button" data-left="142" data-top="474" data-width="378" data-height="40">

                <!-- Sign In Button (Rectangle) -->
                <div id="u29" class="ax_default primary_button1" data-label="Sign In Button">
                  <div id="u29_div" class=""></div>
                  <div id="u29_text" class="text ">
                    <input id="u29_text" type="submit" value="Sign In"style="background-color: #301B3F; color:white" class="u29_text"/>
                  </div>
                </div>

                <!-- Secure Icon (Shape) -->
                <div id="u30" class="ax_default icon" data-label="Secure Icon">
                  <img id="u30_img" class="img " src="images/login_page/secure_icon_u30.svg"/>
                  <div id="u30_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>
              </div>

              <!-- signup_group (Group) -->
              <div id="u31" class="ax_default" data-label="signup_group" data-left="212" data-top="523" data-width="239" data-height="18">

                <!-- No Account Text (Rectangle) -->
                <div id="u32" class="ax_default label" data-label="No Account Text">
                  <div id="u32_div" class=""></div>
                  <div id="u32_text" class="text ">
                    <p><span>Don't have an account?</span></p>
                  </div>
                </div>

                <!-- Unnamed (Rectangle) -->
                <div id="u33" class="ax_default label">
                  <div id="u33_div" class=""></div>
                  <div id="u33_text" class="text ">
                    <p><span>Sign Up</span></p>
                  </div>
                </div>
              </div>
            </div>

            <!-- Unnamed (Line) -->
            <div id="u34" class="ax_default line">
              <img id="u34_img" class="img " src="images/login_page/u34.svg"/>
              <div id="u34_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Sign In Google Button (Rectangle) -->
            <div id="u35" class="ax_default primary_button1" data-label="Sign In Google Button">
              <div id="u35_div" class=""></div>
              <div id="u35_text" class="text ">
                <p><span>Sign In With Google</span></p>
              </div>
            </div>

            <!-- Unnamed (Image) -->
            <div id="u36" class="ax_default image">
              <img id="u36_img" class="img " src="images/login_page/u36.png"/>
              <div id="u36_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Rectangle) -->
            <div id="u37" class="ax_default paragraph">
              <div id="u37_div" class=""></div>
              <div id="u37_text" class="text ">
                <p><span>OR</span></p>
              </div>
            </div>

            <!-- Unnamed (Line) -->
            <div id="u38" class="ax_default line">
              <img id="u38_img" class="img " src="images/login_page/u38.svg"/>
              <div id="u38_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Line) -->
            <div id="u39" class="ax_default line">
              <img id="u39_img" class="img " src="images/login_page/u38.svg"/>
              <div id="u39_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u40" class="ax_default image">
        <img id="u40_img" class="img " src="images/login_page/u40.png"/>
        <div id="u40_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Shape) -->
      <div id="u41" class="ax_default icon">
        <img id="u41_img" class="img " src="images/login_page/u41.svg"/>
        <div id="u41_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>
    </div>
    <script src="resources/scripts/axure/ios.js"></script>

     <?php 

    $host = "localhost";
    $dbusername = "root";
    $dbpassword = "";
    $dbname = "audace_db";
    $conn = mysqli_connect($host, $dbusername, $dbpassword, $dbname);

    if (!$conn) {
        echo "Connection failed!";
    }

    session_start(); 

    if (isset($_POST['u20_input']) && isset($_POST['u25_input'])) {
        function validate($data){
           $data = trim($data);
           $data = stripslashes($data);
           $data = htmlspecialchars($data);
           return $data;
        }

        $emailid = validate($_POST['u20_input']);

        $password = validate($_POST['u25_input']);

        if (empty($emailid)) {

            header("Location: login_page-admin.php?error=User Name is required");

            exit();

        }else if(empty($password)){

            header("Location: login_page-admin.php?error=Password is required");

            exit();

        }else{

            $sql = "SELECT * FROM user_profile WHERE email='$emailid' AND password='$password'";

            $result = mysqli_query($conn, $sql);

            if (mysqli_num_rows($result) === 1) {
                $row = mysqli_fetch_assoc($result);
                if ($row['email'] === $emailid && $row['password'] === $password) {
                    echo "Logged in!";
                    $_SESSION['email'] = $row['email'];
                    $_SESSION['name'] = $row['full_name'];

                    //Redirect to new page
                    //header("Location: home_page.php");

                    exit();

                }else{
                    echo "Incorrect username or password!";         
                    exit();

                }

            }else{
                echo "Incorrect username or password!";
                exit();

            }

        }

    }else{

         header("Location: home_page.php.php");

        exit();

    }
?>

  </form>
  
  </body>
</html>
