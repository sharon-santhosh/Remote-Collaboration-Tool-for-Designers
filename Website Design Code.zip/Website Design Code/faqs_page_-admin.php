﻿<!DOCTYPE html>
<html>
  <head>
    <title>FAQs Page -Admin</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/faqs_page_-admin/styles.css" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="resources/scripts/axure/axQuery.js"></script>
    <script src="resources/scripts/axure/globals.js"></script>
    <script src="resources/scripts/axutils.js"></script>
    <script src="resources/scripts/axure/annotation.js"></script>
    <script src="resources/scripts/axure/axQuery.std.js"></script>
    <script src="resources/scripts/axure/doc.js"></script>
    <script src="resources/scripts/messagecenter.js"></script>
    <script src="resources/scripts/axure/events.js"></script>
    <script src="resources/scripts/axure/recording.js"></script>
    <script src="resources/scripts/axure/action.js"></script>
    <script src="resources/scripts/axure/expr.js"></script>
    <script src="resources/scripts/axure/geometry.js"></script>
    <script src="resources/scripts/axure/flyout.js"></script>
    <script src="resources/scripts/axure/model.js"></script>
    <script src="resources/scripts/axure/repeater.js"></script>
    <script src="resources/scripts/axure/sto.js"></script>
    <script src="resources/scripts/axure/utils.temp.js"></script>
    <script src="resources/scripts/axure/variables.js"></script>
    <script src="resources/scripts/axure/drag.js"></script>
    <script src="resources/scripts/axure/move.js"></script>
    <script src="resources/scripts/axure/visibility.js"></script>
    <script src="resources/scripts/axure/style.js"></script>
    <script src="resources/scripts/axure/adaptive.js"></script>
    <script src="resources/scripts/axure/tree.js"></script>
    <script src="resources/scripts/axure/init.temp.js"></script>
    <script src="resources/scripts/axure/legacy.js"></script>
    <script src="resources/scripts/axure/viewer.js"></script>
    <script src="resources/scripts/axure/math.js"></script>
    <script src="resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="data/document.js"></script>
    <script src="files/faqs_page_-admin/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">

      <!-- Unnamed (Rectangle) -->
      <div id="u468" class="ax_default box_1">
        <div id="u468_div" class=""></div>
        <div id="u468_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u469" class="ax_default box_2">
        <div id="u469_div" class=""></div>
        <div id="u469_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u470" class="ax_default paragraph">
        <div id="u470_div" class=""></div>
        <div id="u470_text" class="text ">
          <p><span>The following are answers to some of the most common questions or problems users come across.</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u471" class="ax_default paragraph">
        <div id="u471_div" class=""></div>
        <div id="u471_text" class="text ">
          <p><span>Can I download Audace on my PC or Mac?</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u472" class="ax_default paragraph">
        <div id="u472_div" class=""></div>
        <div id="u472_text" class="text ">
          <p><span>Audace is a web based collaboration software. It is not available for download on any PC or Mac. However, users can easily login to their account using the website and make use of all the features.</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u473" class="ax_default box_2">
        <div id="u473_div" class=""></div>
        <div id="u473_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u474" class="ax_default paragraph">
        <div id="u474_div" class=""></div>
        <div id="u474_text" class="text ">
          <p><span>Do you need an account to use Audace?</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u475" class="ax_default paragraph">
        <div id="u475_div" class=""></div>
        <div id="u475_text" class="text ">
          <p><span>An Audace account is required to access all the collaboration tools. It allows you to create your own meetings and send invitations to participants. Having an account allows you to create your own instant Meetings or schedule Meetings. An account also allows you to access your personal settings, where you can update your profile or access admin settings depending upon the type of account that you have. </span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u476" class="ax_default box_2">
        <div id="u476_div" class=""></div>
        <div id="u476_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u477" class="ax_default paragraph">
        <div id="u477_div" class=""></div>
        <div id="u477_text" class="text ">
          <p><span>How to I sign up for Audace?</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u478" class="ax_default paragraph">
        <div id="u478_div" class=""></div>
        <div id="u478_text" class="text ">
          <p><span>You can sign up for a free Audace account by clicking the&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; button on the top right corner of the homepage.</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u479" class="ax_default link_button">
        <div id="u479_div" class=""></div>
        <div id="u479_text" class="text ">
          <p><span>Get Started</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u480" class="ax_default box_2">
        <div id="u480_div" class=""></div>
        <div id="u480_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u481" class="ax_default paragraph">
        <div id="u481_div" class=""></div>
        <div id="u481_text" class="text ">
          <p><span>How do I schedule and invite others to my meeting?</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u482" class="ax_default paragraph">
        <div id="u482_div" class=""></div>
        <div id="u482_text" class="text ">
          <p><span>You can schedule a meeting on the web and invite others to join your meeting by copying the join URL or meeting invitation and sending it out via email or other text messengers.</span></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u483" class="ax_default image">
        <img id="u483_img" class="img " src="images/meetings-admin/u129.png"/>
        <div id="u483_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u484" class="ax_default paragraph">
        <div id="u484_div" class=""></div>
        <div id="u484_text" class="text ">
          <p><span>FAQ's</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u485" class="ax_default box_1">
        <div id="u485_div" class=""></div>
        <div id="u485_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u486" class="ax_default paragraph">
        <div id="u486_div" class=""></div>
        <div id="u486_text" class="text ">
          <p><span style="text-decoration:underline ;">PERSONAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u487" class="ax_default button">
        <div id="u487_div" class=""></div>
        <div id="u487_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Home</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u488" class="ax_default button">
        <div id="u488_div" class=""></div>
        <div id="u488_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Profile</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u489" class="ax_default button">
        <div id="u489_div" class=""></div>
        <div id="u489_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Meetings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u490" class="ax_default button">
        <div id="u490_div" class=""></div>
        <div id="u490_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Chat</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u491" class="ax_default paragraph">
        <div id="u491_div" class=""></div>
        <div id="u491_text" class="text ">
          <p><span style="text-decoration:underline ;">ADMIN</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u492" class="ax_default button">
        <div id="u492_div" class=""></div>
        <div id="u492_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; View Projects</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u493" class="ax_default button">
        <div id="u493_div" class=""></div>
        <div id="u493_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Manage Projects</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u494" class="ax_default button">
        <div id="u494_div" class=""></div>
        <div id="u494_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Announcements</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u495" class="ax_default button">
        <div id="u495_div" class=""></div>
        <div id="u495_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Manage Groups</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u496" class="ax_default paragraph">
        <div id="u496_div" class=""></div>
        <div id="u496_text" class="text ">
          <p><span style="text-decoration:underline ;">GENERAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u497" class="ax_default button">
        <div id="u497_div" class=""></div>
        <div id="u497_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Settings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u498" class="ax_default button">
        <div id="u498_div" class=""></div>
        <div id="u498_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Help</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u499" class="ax_default button">
        <div id="u499_div" class=""></div>
        <div id="u499_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; FAQs</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u500" class="ax_default button">
        <div id="u500_div" class=""></div>
        <div id="u500_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Manage Employees</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u501" class="ax_default button">
        <div id="u501_div" class=""></div>
        <div id="u501_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; View Employees</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u502" class="ax_default button">
        <div id="u502_div" class=""></div>
        <div id="u502_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; View Groups</span></p>
        </div>
      </div>

      <!-- Unnamed (Dynamic Panel) -->
      <div id="u503" class="ax_default">
        <div id="u503_state0" class="panel_state" data-label="State 1" style="">
          <div id="u503_state0_content" class="panel_state_content">

            <!-- Unnamed (Rectangle) -->
            <div id="u504" class="ax_default box_1">
              <div id="u504_div" class=""></div>
              <div id="u504_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Image) -->
            <div id="u505" class="ax_default image">
              <img id="u505_img" class="img " src="images/home_page/u3.png"/>
              <div id="u505_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u506" class="ax_default icon">
              <img id="u506_img" class="img " src="images/homepage-admin/u107.svg"/>
              <div id="u506_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u507" class="ax_default icon">
              <img id="u507_img" class="img " src="images/homepage-admin/u108.svg"/>
              <div id="u507_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u508" class="ax_default icon">
              <img id="u508_img" class="img " src="images/homepage-admin/u109.svg"/>
              <div id="u508_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script src="resources/scripts/axure/ios.js"></script>
  </body>
</html>
