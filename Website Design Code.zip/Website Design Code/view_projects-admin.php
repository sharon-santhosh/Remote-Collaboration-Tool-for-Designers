﻿<!DOCTYPE html>
<html>
  <head>
    <title>View Projects-Admin</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/view_projects-admin/styles.css" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="resources/scripts/axure/axQuery.js"></script>
    <script src="resources/scripts/axure/globals.js"></script>
    <script src="resources/scripts/axutils.js"></script>
    <script src="resources/scripts/axure/annotation.js"></script>
    <script src="resources/scripts/axure/axQuery.std.js"></script>
    <script src="resources/scripts/axure/doc.js"></script>
    <script src="resources/scripts/messagecenter.js"></script>
    <script src="resources/scripts/axure/events.js"></script>
    <script src="resources/scripts/axure/recording.js"></script>
    <script src="resources/scripts/axure/action.js"></script>
    <script src="resources/scripts/axure/expr.js"></script>
    <script src="resources/scripts/axure/geometry.js"></script>
    <script src="resources/scripts/axure/flyout.js"></script>
    <script src="resources/scripts/axure/model.js"></script>
    <script src="resources/scripts/axure/repeater.js"></script>
    <script src="resources/scripts/axure/sto.js"></script>
    <script src="resources/scripts/axure/utils.temp.js"></script>
    <script src="resources/scripts/axure/variables.js"></script>
    <script src="resources/scripts/axure/drag.js"></script>
    <script src="resources/scripts/axure/move.js"></script>
    <script src="resources/scripts/axure/visibility.js"></script>
    <script src="resources/scripts/axure/style.js"></script>
    <script src="resources/scripts/axure/adaptive.js"></script>
    <script src="resources/scripts/axure/tree.js"></script>
    <script src="resources/scripts/axure/init.temp.js"></script>
    <script src="resources/scripts/axure/legacy.js"></script>
    <script src="resources/scripts/axure/viewer.js"></script>
    <script src="resources/scripts/axure/math.js"></script>
    <script src="resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="data/document.js"></script>
    <script src="files/view_projects-admin/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">

      <!-- black_box (Rectangle) -->
      <div id="u441" class="ax_default box_1" data-label="black_box">
        <div id="u441_div" class=""></div>
        <div id="u441_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u442" class="ax_default image">
        <img id="u442_img" class="img " src="images/meetings-admin/u129.png"/>
        <div id="u442_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u443" class="ax_default paragraph">
        <div id="u443_div" class=""></div>
        <div id="u443_text" class="text ">
          <p><span>VIEW PROJECTS</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u444" class="ax_default box_1">
        <div id="u444_div" class=""></div>
        <div id="u444_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u445" class="ax_default paragraph">
        <div id="u445_div" class=""></div>
        <div id="u445_text" class="text ">
          <p><span style="text-decoration:underline ;">PERSONAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u446" class="ax_default button">
        <div id="u446_div" class=""></div>
        <div id="u446_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Home</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u447" class="ax_default button">
        <div id="u447_div" class=""></div>
        <div id="u447_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Profile</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u448" class="ax_default button">
        <div id="u448_div" class=""></div>
        <div id="u448_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Meetings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u449" class="ax_default button">
        <div id="u449_div" class=""></div>
        <div id="u449_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Chat</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u450" class="ax_default paragraph">
        <div id="u450_div" class=""></div>
        <div id="u450_text" class="text ">
          <p><span style="text-decoration:underline ;">ADMIN</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u451" class="ax_default button">
        <div id="u451_div" class=""></div>
        <div id="u451_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; View Projects</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u452" class="ax_default button">
        <div id="u452_div" class=""></div>
        <div id="u452_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Manage Projects</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u453" class="ax_default button">
        <div id="u453_div" class=""></div>
        <div id="u453_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Announcements</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u454" class="ax_default button">
        <div id="u454_div" class=""></div>
        <div id="u454_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Manage Groups</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u455" class="ax_default paragraph">
        <div id="u455_div" class=""></div>
        <div id="u455_text" class="text ">
          <p><span style="text-decoration:underline ;">GENERAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u456" class="ax_default button">
        <div id="u456_div" class=""></div>
        <div id="u456_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Settings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u457" class="ax_default button">
        <div id="u457_div" class=""></div>
        <div id="u457_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Help</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u458" class="ax_default button">
        <div id="u458_div" class=""></div>
        <div id="u458_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; FAQs</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u459" class="ax_default button">
        <div id="u459_div" class=""></div>
        <div id="u459_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Manage Employees</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u460" class="ax_default button">
        <div id="u460_div" class=""></div>
        <div id="u460_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; View Employees</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u461" class="ax_default button">
        <div id="u461_div" class=""></div>
        <div id="u461_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; View Groups</span></p>
        </div>
      </div>

      <!-- Unnamed (Dynamic Panel) -->
      <div id="u462" class="ax_default">
        <div id="u462_state0" class="panel_state" data-label="State 1" style="">
          <div id="u462_state0_content" class="panel_state_content">

            <!-- Unnamed (Rectangle) -->
            <div id="u463" class="ax_default box_1">
              <div id="u463_div" class=""></div>
              <div id="u463_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Image) -->
            <div id="u464" class="ax_default image">
              <img id="u464_img" class="img " src="images/home_page/u3.png"/>
              <div id="u464_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u465" class="ax_default icon">
              <img id="u465_img" class="img " src="images/homepage-admin/u107.svg"/>
              <div id="u465_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u466" class="ax_default icon">
              <img id="u466_img" class="img " src="images/homepage-admin/u108.svg"/>
              <div id="u466_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u467" class="ax_default icon">
              <img id="u467_img" class="img " src="images/homepage-admin/u109.svg"/>
              <div id="u467_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script src="resources/scripts/axure/ios.js"></script>

    <div class="image-block"> 

       <?php

      //get current directory
      $working_dir = getcwd();
      
      //get image directory
      $img_dir = $working_dir . "/photo/";
      
      //change current directory to image directory
      chdir($img_dir);
      
      //using glob() function get images 
      $files = glob("*.{jpg,jpeg,png,gif,JPG,JPEG,PNG,GIF}", GLOB_BRACE );
      
      //again change the directory to working directory
      chdir($working_dir);

      //iterate over image files
      foreach ($files as $file) {
      ?>
        <img src="<?php echo "photo/" . $file ?>" class="img-responsive" style="height: 200px; width: 200px; margin-top: -30px; margin-left: 80px; margin-right: 0px; margin-bottom: 50px;"/>
      <?php }
    ?>
    </div>

  </body>
</html>
