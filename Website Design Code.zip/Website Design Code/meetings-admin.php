﻿<!DOCTYPE html>
<html>
  <head>
    <title>Meetings-Admin</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/meetings-admin/styles.css" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="resources/scripts/axure/axQuery.js"></script>
    <script src="resources/scripts/axure/globals.js"></script>
    <script src="resources/scripts/axutils.js"></script>
    <script src="resources/scripts/axure/annotation.js"></script>
    <script src="resources/scripts/axure/axQuery.std.js"></script>
    <script src="resources/scripts/axure/doc.js"></script>
    <script src="resources/scripts/messagecenter.js"></script>
    <script src="resources/scripts/axure/events.js"></script>
    <script src="resources/scripts/axure/recording.js"></script>
    <script src="resources/scripts/axure/action.js"></script>
    <script src="resources/scripts/axure/expr.js"></script>
    <script src="resources/scripts/axure/geometry.js"></script>
    <script src="resources/scripts/axure/flyout.js"></script>
    <script src="resources/scripts/axure/model.js"></script>
    <script src="resources/scripts/axure/repeater.js"></script>
    <script src="resources/scripts/axure/sto.js"></script>
    <script src="resources/scripts/axure/utils.temp.js"></script>
    <script src="resources/scripts/axure/variables.js"></script>
    <script src="resources/scripts/axure/drag.js"></script>
    <script src="resources/scripts/axure/move.js"></script>
    <script src="resources/scripts/axure/visibility.js"></script>
    <script src="resources/scripts/axure/style.js"></script>
    <script src="resources/scripts/axure/adaptive.js"></script>
    <script src="resources/scripts/axure/tree.js"></script>
    <script src="resources/scripts/axure/init.temp.js"></script>
    <script src="resources/scripts/axure/legacy.js"></script>
    <script src="resources/scripts/axure/viewer.js"></script>
    <script src="resources/scripts/axure/math.js"></script>
    <script src="resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="data/document.js"></script>
    <script src="files/meetings-admin/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">

      <!-- Unnamed (Rectangle) -->
      <div id="u128" class="ax_default box_1">
        <div id="u128_div" class=""></div>
        <div id="u128_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u129" class="ax_default image">
        <img id="u129_img" class="img " src="images/meetings-admin/u129.png"/>
        <div id="u129_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u130" class="ax_default paragraph">
        <div id="u130_div" class=""></div>
        <div id="u130_text" class="text ">
          <p><span>MEETINGS</span></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u131" class="ax_default image">
        <img id="u131_img" class="img " src="images/registration_page/u62.png"/>
        <div id="u131_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u132" class="ax_default paragraph">
        <div id="u132_div" class=""></div>
        <div id="u132_text" class="text ">
          <p><span style="color:#DBD8E3;">Connect </span><span style="color:#C31ED7;">Without</span></p><p><span style="color:#C31ED7;">Limits </span><span style="color:#DBD8E3;">With Your </span></p><p><span style="color:#DBD8E3;">Team Mates!</span></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u133" class="ax_default image">
        <img id="u133_img" class="img " src="images/registration_page/u73.png"/>
        <div id="u133_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u134" class="ax_default box_1">
        <div id="u134_div" class=""></div>
        <div id="u134_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Ellipse) -->
      <div id="u135" class="ax_default ellipse">
        <img id="u135_img" class="img " src="images/meetings-admin/u135.svg"/>
        <div id="u135_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Ellipse) -->
      <div id="u136" class="ax_default ellipse">
        <img id="u136_img" class="img " src="images/meetings-admin/u136.svg"/>
        <div id="u136_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Shape) -->
      <div id="u137" class="ax_default icon">
        <img id="u137_img" class="img " src="images/meetings-admin/u137.svg"/>
        <div id="u137_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Shape) -->
      <div id="u138" class="ax_default icon">
        <img id="u138_img" class="img " src="images/meetings-admin/u138.svg"/>
        <div id="u138_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u139" class="ax_default image">
        <img id="u139_img" class="img " src="images/registration_page/u73.png"/>
        <div id="u139_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u140" class="ax_default box_2">
        <div id="u140_div" class=""></div>
        <div id="u140_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u141" class="ax_default box_2">
        <div id="u141_div" class=""></div>
        <div id="u141_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u142" class="ax_default box_2">
        <div id="u142_div" class=""></div>
        <div id="u142_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u143" class="ax_default box_2">
        <div id="u143_div" class=""></div>
        <div id="u143_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u144" class="ax_default image">
        <img id="u144_img" class="img " src="images/meetings-admin/u144.png"/>
        <div id="u144_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u145" class="ax_default box_2">
        <div id="u145_div" class=""></div>
        <div id="u145_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u146" class="ax_default box_3">
        <div id="u146_div" class=""></div>
        <div id="u146_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Conference Rooms (Dynamic Panel) -->
      <div id="u147" class="ax_default" data-label="Conference Rooms">
        <div id="u147_state0" class="panel_state" data-label="State 1" style="">
          <div id="u147_state0_content" class="panel_state_content">

            <!-- Unnamed (Image) -->
            <div id="u148" class="ax_default image">
              <img id="u148_img" class="img " src="images/meetings-admin/u148.svg"/>
              <div id="u148_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Rectangle) -->
            <div id="u149" class="ax_default paragraph">
              <div id="u149_div" class=""></div>
              <div id="u149_text" class="text ">
                <p><span>Conference Rooms</span></p>
              </div>
            </div>

            <!-- Unnamed (Line) -->
            <div id="u150" class="ax_default line">
              <img id="u150_img" class="img " src="images/meetings-admin/u150.svg"/>
              <div id="u150_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Rectangle) -->
            <div id="u151" class="ax_default paragraph">
              <div id="u151_div" class=""></div>
              <div id="u151_text" class="text ">
                <p><span>Adapt your conference rooms to changing needs with HD video and audio, wireless content sharing, and interactive whiteboarding.</span></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Meetings (Dynamic Panel) -->
      <div id="u152" class="ax_default" data-label="Meetings">
        <div id="u152_state0" class="panel_state" data-label="State 1" style="">
          <div id="u152_state0_content" class="panel_state_content">

            <!-- Unnamed (Rectangle) -->
            <div id="u153" class="ax_default paragraph">
              <div id="u153_div" class=""></div>
              <div id="u153_text" class="text ">
                <p><span>Meetings</span></p>
              </div>
            </div>

            <!-- Unnamed (Line) -->
            <div id="u154" class="ax_default line">
              <img id="u154_img" class="img " src="images/meetings-admin/u154.svg"/>
              <div id="u154_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Rectangle) -->
            <div id="u155" class="ax_default paragraph">
              <div id="u155_div" class=""></div>
              <div id="u155_text" class="text ">
                <p><span>Build stronger relationships, supercharge collaboration, and create an engaging meeting experience with HD video and audio.</span></p>
              </div>
            </div>

            <!-- Unnamed (Rectangle) -->
            <div id="u156" class="ax_default box_1">
              <div id="u156_div" class=""></div>
              <div id="u156_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u157" class="ax_default icon">
              <img id="u157_img" class="img " src="images/meetings-admin/u157.svg"/>
              <div id="u157_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Chat (Dynamic Panel) -->
      <div id="u158" class="ax_default" data-label="Chat">
        <div id="u158_state0" class="panel_state" data-label="State 1" style="">
          <div id="u158_state0_content" class="panel_state_content">

            <!-- Unnamed (Image) -->
            <div id="u159" class="ax_default image">
              <img id="u159_img" class="img " src="images/meetings-admin/u159.svg"/>
              <div id="u159_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Rectangle) -->
            <div id="u160" class="ax_default paragraph">
              <div id="u160_div" class=""></div>
              <div id="u160_text" class="text ">
                <p><span>Chat</span></p>
              </div>
            </div>

            <!-- Unnamed (Line) -->
            <div id="u161" class="ax_default line">
              <img id="u161_img" class="img " src="images/meetings-admin/u161.svg"/>
              <div id="u161_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Rectangle) -->
            <div id="u162" class="ax_default paragraph">
              <div id="u162_div" class=""></div>
              <div id="u162_text" class="text ">
                <p><span>Our chat solution simplifies workflows, boosts productivity, and ensures employees can collaborate securely, both internally and externally.</span></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Phone Systems (Dynamic Panel) -->
      <div id="u163" class="ax_default" data-label="Phone Systems">
        <div id="u163_state0" class="panel_state" data-label="State 1" style="">
          <div id="u163_state0_content" class="panel_state_content">

            <!-- Unnamed (Rectangle) -->
            <div id="u164" class="ax_default paragraph">
              <div id="u164_div" class=""></div>
              <div id="u164_text" class="text ">
                <p><span>Phone System</span></p>
              </div>
            </div>

            <!-- Unnamed (Line) -->
            <div id="u165" class="ax_default line">
              <img id="u165_img" class="img " src="images/meetings-admin/u165.svg"/>
              <div id="u165_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Rectangle) -->
            <div id="u166" class="ax_default paragraph">
              <div id="u166_div" class=""></div>
              <div id="u166_text" class="text ">
                <p><span>Power your voice communications with our global cloud phone solution with secure call routing, call queues, SMS, elevate calls to meetings, and more.</span></p>
              </div>
            </div>

            <!-- Unnamed (Image) -->
            <div id="u167" class="ax_default image">
              <img id="u167_img" class="img " src="images/meetings-admin/u167.svg"/>
              <div id="u167_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u168" class="ax_default image">
        <img id="u168_img" class="img " src="images/meetings-admin/u168.svg"/>
        <div id="u168_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Video Webinars (Dynamic Panel) -->
      <div id="u169" class="ax_default" data-label="Video Webinars">
        <div id="u169_state0" class="panel_state" data-label="State 1" style="">
          <div id="u169_state0_content" class="panel_state_content">

            <!-- Unnamed (Rectangle) -->
            <div id="u170" class="ax_default paragraph">
              <div id="u170_div" class=""></div>
              <div id="u170_text" class="text ">
                <p><span>Video Webinars</span></p>
              </div>
            </div>

            <!-- Unnamed (Line) -->
            <div id="u171" class="ax_default line">
              <img id="u171_img" class="img " src="images/meetings-admin/u171.svg"/>
              <div id="u171_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Rectangle) -->
            <div id="u172" class="ax_default paragraph">
              <div id="u172_div" class=""></div>
              <div id="u172_text" class="text ">
                <p><span>Create virtual experiences that attendees will love. Get started today with Zoom Events and Video Webinars.</span></p>
              </div>
            </div>

            <!-- Unnamed (Image) -->
            <div id="u173" class="ax_default image">
              <img id="u173_img" class="img " src="images/meetings-admin/u173.svg"/>
              <div id="u173_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u174" class="ax_default box_1">
        <div id="u174_div" class=""></div>
        <div id="u174_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u175" class="ax_default paragraph">
        <div id="u175_div" class=""></div>
        <div id="u175_text" class="text ">
          <p><span style="text-decoration:underline ;">PERSONAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u176" class="ax_default button">
        <div id="u176_div" class=""></div>
        <div id="u176_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Home</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u177" class="ax_default button">
        <div id="u177_div" class=""></div>
        <div id="u177_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Profile</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u178" class="ax_default button">
        <div id="u178_div" class=""></div>
        <div id="u178_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Meetings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u179" class="ax_default button">
        <div id="u179_div" class=""></div>
        <div id="u179_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Chat</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u180" class="ax_default paragraph">
        <div id="u180_div" class=""></div>
        <div id="u180_text" class="text ">
          <p><span style="text-decoration:underline ;">ADMIN</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u181" class="ax_default button">
        <div id="u181_div" class=""></div>
        <div id="u181_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; View Projects</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u182" class="ax_default button">
        <div id="u182_div" class=""></div>
        <div id="u182_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Manage Projects</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u183" class="ax_default button">
        <div id="u183_div" class=""></div>
        <div id="u183_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Announcements</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u184" class="ax_default button">
        <div id="u184_div" class=""></div>
        <div id="u184_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Manage Groups</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u185" class="ax_default paragraph">
        <div id="u185_div" class=""></div>
        <div id="u185_text" class="text ">
          <p><span style="text-decoration:underline ;">GENERAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u186" class="ax_default button">
        <div id="u186_div" class=""></div>
        <div id="u186_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Settings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u187" class="ax_default button">
        <div id="u187_div" class=""></div>
        <div id="u187_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Help</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u188" class="ax_default button">
        <div id="u188_div" class=""></div>
        <div id="u188_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; FAQs</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u189" class="ax_default button">
        <div id="u189_div" class=""></div>
        <div id="u189_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Manage Employees</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u190" class="ax_default button">
        <div id="u190_div" class=""></div>
        <div id="u190_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; View Employees</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u191" class="ax_default button">
        <div id="u191_div" class=""></div>
        <div id="u191_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; View Groups</span></p>
        </div>
      </div>

      <!-- Unnamed (Dynamic Panel) -->
      <div id="u192" class="ax_default">
        <div id="u192_state0" class="panel_state" data-label="State 1" style="">
          <div id="u192_state0_content" class="panel_state_content">

            <!-- Unnamed (Rectangle) -->
            <div id="u193" class="ax_default box_1">
              <div id="u193_div" class=""></div>
              <div id="u193_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Image) -->
            <div id="u194" class="ax_default image">
              <img id="u194_img" class="img " src="images/home_page/u3.png"/>
              <div id="u194_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u195" class="ax_default icon">
              <img id="u195_img" class="img " src="images/homepage-admin/u107.svg"/>
              <div id="u195_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u196" class="ax_default icon">
              <img id="u196_img" class="img " src="images/homepage-admin/u108.svg"/>
              <div id="u196_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u197" class="ax_default icon">
              <img id="u197_img" class="img " src="images/homepage-admin/u109.svg"/>
              <div id="u197_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script src="resources/scripts/axure/ios.js"></script>
  </body>
</html>
