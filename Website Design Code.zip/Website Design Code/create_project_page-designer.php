﻿<!DOCTYPE html>
<html>
  <head>
    <title>Create Project Page-Designer</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/create_project_page-designer/styles.css" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="resources/scripts/axure/axQuery.js"></script>
    <script src="resources/scripts/axure/globals.js"></script>
    <script src="resources/scripts/axutils.js"></script>
    <script src="resources/scripts/axure/annotation.js"></script>
    <script src="resources/scripts/axure/axQuery.std.js"></script>
    <script src="resources/scripts/axure/doc.js"></script>
    <script src="resources/scripts/messagecenter.js"></script>
    <script src="resources/scripts/axure/events.js"></script>
    <script src="resources/scripts/axure/recording.js"></script>
    <script src="resources/scripts/axure/action.js"></script>
    <script src="resources/scripts/axure/expr.js"></script>
    <script src="resources/scripts/axure/geometry.js"></script>
    <script src="resources/scripts/axure/flyout.js"></script>
    <script src="resources/scripts/axure/model.js"></script>
    <script src="resources/scripts/axure/repeater.js"></script>
    <script src="resources/scripts/axure/sto.js"></script>
    <script src="resources/scripts/axure/utils.temp.js"></script>
    <script src="resources/scripts/axure/variables.js"></script>
    <script src="resources/scripts/axure/drag.js"></script>
    <script src="resources/scripts/axure/move.js"></script>
    <script src="resources/scripts/axure/visibility.js"></script>
    <script src="resources/scripts/axure/style.js"></script>
    <script src="resources/scripts/axure/adaptive.js"></script>
    <script src="resources/scripts/axure/tree.js"></script>
    <script src="resources/scripts/axure/init.temp.js"></script>
    <script src="resources/scripts/axure/legacy.js"></script>
    <script src="resources/scripts/axure/viewer.js"></script>
    <script src="resources/scripts/axure/math.js"></script>
    <script src="resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="data/document.js"></script>
    <script src="files/create_project_page-designer/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">

      <!-- Unnamed (Rectangle) -->
      <div id="u643" class="ax_default box_1">
        <div id="u643_div" class=""></div>
        <div id="u643_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u644" class="ax_default image">
        <img id="u644_img" class="img " src="images/meetings-admin/u129.png"/>
        <div id="u644_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u645" class="ax_default paragraph">
        <div id="u645_div" class=""></div>
        <div id="u645_text" class="text ">
          <p><span>CREATE PROJECTS</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u646" class="ax_default box_2">
        <div id="u646_div" class=""></div>
        <div id="u646_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u647" class="ax_default box_2">
        <div id="u647_div" class=""></div>
        <div id="u647_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u648" class="ax_default image">
        <img id="u648_img" class="img " src="images/create_project_page-designer/u648.svg"/>
        <div id="u648_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u649" class="ax_default image">
        <img id="u649_img" class="img " src="images/create_project_page-designer/u649.svg"/>
        <div id="u649_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u650" class="ax_default paragraph">
        <div id="u650_div" class=""></div>
        <div id="u650_text" class="text ">
          <p><span>Want to work individually?</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u651" class="ax_default paragraph">
        <div id="u651_div" class=""></div>
        <div id="u651_text" class="text ">
          <p><span>Click the button below to redirect you to your own personal workspace.</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u652" class="ax_default button">
        <div id="u652_div" class=""></div>
        <div id="u652_text" class="text ">
          <p><span>Personal Workspace</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u653" class="ax_default paragraph">
        <div id="u653_div" class=""></div>
        <div id="u653_text" class="text ">
          <p><span>Want to work together?</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u654" class="ax_default button">
        <div id="u654_div" class=""></div>
        <div id="u654_text" class="text ">
          <p><span>Collaborative Workspace</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u655" class="ax_default paragraph">
        <div id="u655_div" class=""></div>
        <div id="u655_text" class="text ">
          <p><span>Click the button below to redirect you to a collaborative workspace.</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u656" class="ax_default box_1">
        <div id="u656_div" class=""></div>
        <div id="u656_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u657" class="ax_default paragraph">
        <div id="u657_div" class=""></div>
        <div id="u657_text" class="text ">
          <p><span style="text-decoration:underline ;">PERSONAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u658" class="ax_default button">
        <div id="u658_div" class=""></div>
        <div id="u658_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Home</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u659" class="ax_default button">
        <div id="u659_div" class=""></div>
        <div id="u659_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Profile</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u660" class="ax_default button">
        <div id="u660_div" class=""></div>
        <div id="u660_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Meetings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u661" class="ax_default button">
        <div id="u661_div" class=""></div>
        <div id="u661_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Chat</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u662" class="ax_default paragraph">
        <div id="u662_div" class=""></div>
        <div id="u662_text" class="text ">
          <p><span style="text-decoration:underline ;">TEAM</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u663" class="ax_default button">
        <div id="u663_div" class=""></div>
        <div id="u663_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Create a project</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u664" class="ax_default button">
        <div id="u664_div" class=""></div>
        <div id="u664_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Completed projects</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u665" class="ax_default button">
        <div id="u665_div" class=""></div>
        <div id="u665_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Announcements</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u666" class="ax_default button">
        <div id="u666_div" class=""></div>
        <div id="u666_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Groups</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u667" class="ax_default paragraph">
        <div id="u667_div" class=""></div>
        <div id="u667_text" class="text ">
          <p><span style="text-decoration:underline ;">GENERAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u668" class="ax_default button">
        <div id="u668_div" class=""></div>
        <div id="u668_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Settings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u669" class="ax_default button">
        <div id="u669_div" class=""></div>
        <div id="u669_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Help</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u670" class="ax_default button">
        <div id="u670_div" class=""></div>
        <div id="u670_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; FAQs</span></p>
        </div>
      </div>

      <!-- Unnamed (Dynamic Panel) -->
      <div id="u671" class="ax_default">
        <div id="u671_state0" class="panel_state" data-label="State 1" style="">
          <div id="u671_state0_content" class="panel_state_content">

            <!-- Unnamed (Rectangle) -->
            <div id="u672" class="ax_default box_1">
              <div id="u672_div" class=""></div>
              <div id="u672_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Image) -->
            <div id="u673" class="ax_default image">
              <img id="u673_img" class="img " src="images/home_page/u3.png"/>
              <div id="u673_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u674" class="ax_default icon">
              <img id="u674_img" class="img " src="images/homepage-admin/u107.svg"/>
              <div id="u674_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u675" class="ax_default icon">
              <img id="u675_img" class="img " src="images/homepage-admin/u108.svg"/>
              <div id="u675_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u676" class="ax_default icon">
              <img id="u676_img" class="img " src="images/homepage-admin/u109.svg"/>
              <div id="u676_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script src="resources/scripts/axure/ios.js"></script>
  </body>
</html>
