﻿<!DOCTYPE html>
<html>
  <head>
    <title>Chats-Designer</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/chats-designer/styles.css" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="resources/scripts/axure/axQuery.js"></script>
    <script src="resources/scripts/axure/globals.js"></script>
    <script src="resources/scripts/axutils.js"></script>
    <script src="resources/scripts/axure/annotation.js"></script>
    <script src="resources/scripts/axure/axQuery.std.js"></script>
    <script src="resources/scripts/axure/doc.js"></script>
    <script src="resources/scripts/messagecenter.js"></script>
    <script src="resources/scripts/axure/events.js"></script>
    <script src="resources/scripts/axure/recording.js"></script>
    <script src="resources/scripts/axure/action.js"></script>
    <script src="resources/scripts/axure/expr.js"></script>
    <script src="resources/scripts/axure/geometry.js"></script>
    <script src="resources/scripts/axure/flyout.js"></script>
    <script src="resources/scripts/axure/model.js"></script>
    <script src="resources/scripts/axure/repeater.js"></script>
    <script src="resources/scripts/axure/sto.js"></script>
    <script src="resources/scripts/axure/utils.temp.js"></script>
    <script src="resources/scripts/axure/variables.js"></script>
    <script src="resources/scripts/axure/drag.js"></script>
    <script src="resources/scripts/axure/move.js"></script>
    <script src="resources/scripts/axure/visibility.js"></script>
    <script src="resources/scripts/axure/style.js"></script>
    <script src="resources/scripts/axure/adaptive.js"></script>
    <script src="resources/scripts/axure/tree.js"></script>
    <script src="resources/scripts/axure/init.temp.js"></script>
    <script src="resources/scripts/axure/legacy.js"></script>
    <script src="resources/scripts/axure/viewer.js"></script>
    <script src="resources/scripts/axure/math.js"></script>
    <script src="resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="data/document.js"></script>
    <script src="files/chats-designer/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">

      <!-- Unnamed (Rectangle) -->
      <div id="u612" class="ax_default box_1">
        <div id="u612_div" class=""></div>
        <div id="u612_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u613" class="ax_default image">
        <img id="u613_img" class="img " src="images/meetings-admin/u129.png"/>
        <div id="u613_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u614" class="ax_default paragraph">
        <div id="u614_div" class=""></div>
        <div id="u614_text" class="text ">
          <p><span>CHAT</span></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u615" class="ax_default image">
        <img id="u615_img" class="img " src="images/chats-admin/u201.png"/>
        <div id="u615_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u616" class="ax_default image">
        <img id="u616_img" class="img " src="images/registration_page/u73.png"/>
        <div id="u616_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u617" class="ax_default image">
        <img id="u617_img" class="img " src="images/chats-admin/u203.png"/>
        <div id="u617_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u618" class="ax_default image">
        <img id="u618_img" class="img " src="images/chats-admin/u201.png"/>
        <div id="u618_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u619" class="ax_default image">
        <img id="u619_img" class="img " src="images/chats-admin/u205.png"/>
        <div id="u619_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u620" class="ax_default image">
        <img id="u620_img" class="img " src="images/chats-admin/u206.png"/>
        <div id="u620_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u621" class="ax_default button">
        <div id="u621_div" class=""></div>
        <div id="u621_text" class="text ">
          <p><span>Continue to Google Chat</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u622" class="ax_default box_1">
        <div id="u622_div" class=""></div>
        <div id="u622_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u623" class="ax_default paragraph">
        <div id="u623_div" class=""></div>
        <div id="u623_text" class="text ">
          <p><span style="text-decoration:underline ;">PERSONAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u624" class="ax_default button">
        <div id="u624_div" class=""></div>
        <div id="u624_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Home</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u625" class="ax_default button">
        <div id="u625_div" class=""></div>
        <div id="u625_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Profile</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u626" class="ax_default button">
        <div id="u626_div" class=""></div>
        <div id="u626_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Meetings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u627" class="ax_default button">
        <div id="u627_div" class=""></div>
        <div id="u627_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Chat</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u628" class="ax_default paragraph">
        <div id="u628_div" class=""></div>
        <div id="u628_text" class="text ">
          <p><span style="text-decoration:underline ;">TEAM</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u629" class="ax_default button">
        <div id="u629_div" class=""></div>
        <div id="u629_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Create a project</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u630" class="ax_default button">
        <div id="u630_div" class=""></div>
        <div id="u630_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Completed projects</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u631" class="ax_default button">
        <div id="u631_div" class=""></div>
        <div id="u631_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Announcements</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u632" class="ax_default button">
        <div id="u632_div" class=""></div>
        <div id="u632_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Groups</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u633" class="ax_default paragraph">
        <div id="u633_div" class=""></div>
        <div id="u633_text" class="text ">
          <p><span style="text-decoration:underline ;">GENERAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u634" class="ax_default button">
        <div id="u634_div" class=""></div>
        <div id="u634_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Settings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u635" class="ax_default button">
        <div id="u635_div" class=""></div>
        <div id="u635_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Help</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u636" class="ax_default button">
        <div id="u636_div" class=""></div>
        <div id="u636_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; FAQs</span></p>
        </div>
      </div>

      <!-- Unnamed (Dynamic Panel) -->
      <div id="u637" class="ax_default">
        <div id="u637_state0" class="panel_state" data-label="State 1" style="">
          <div id="u637_state0_content" class="panel_state_content">

            <!-- Unnamed (Rectangle) -->
            <div id="u638" class="ax_default box_1">
              <div id="u638_div" class=""></div>
              <div id="u638_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Image) -->
            <div id="u639" class="ax_default image">
              <img id="u639_img" class="img " src="images/home_page/u3.png"/>
              <div id="u639_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u640" class="ax_default icon">
              <img id="u640_img" class="img " src="images/homepage-admin/u107.svg"/>
              <div id="u640_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u641" class="ax_default icon">
              <img id="u641_img" class="img " src="images/homepage-admin/u108.svg"/>
              <div id="u641_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u642" class="ax_default icon">
              <img id="u642_img" class="img " src="images/homepage-admin/u109.svg"/>
              <div id="u642_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script src="resources/scripts/axure/ios.js"></script>
  </body>
</html>
