﻿<!DOCTYPE html>
<html>
  <head>
    <title>Registration Page</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/registration_page/styles.css" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="resources/scripts/axure/axQuery.js"></script>
    <script src="resources/scripts/axure/globals.js"></script>
    <script src="resources/scripts/axutils.js"></script>
    <script src="resources/scripts/axure/annotation.js"></script>
    <script src="resources/scripts/axure/axQuery.std.js"></script>
    <script src="resources/scripts/axure/doc.js"></script>
    <script src="resources/scripts/messagecenter.js"></script>
    <script src="resources/scripts/axure/events.js"></script>
    <script src="resources/scripts/axure/recording.js"></script>
    <script src="resources/scripts/axure/action.js"></script>
    <script src="resources/scripts/axure/expr.js"></script>
    <script src="resources/scripts/axure/geometry.js"></script>
    <script src="resources/scripts/axure/flyout.js"></script>
    <script src="resources/scripts/axure/model.js"></script>
    <script src="resources/scripts/axure/repeater.js"></script>
    <script src="resources/scripts/axure/sto.js"></script>
    <script src="resources/scripts/axure/utils.temp.js"></script>
    <script src="resources/scripts/axure/variables.js"></script>
    <script src="resources/scripts/axure/drag.js"></script>
    <script src="resources/scripts/axure/move.js"></script>
    <script src="resources/scripts/axure/visibility.js"></script>
    <script src="resources/scripts/axure/style.js"></script>
    <script src="resources/scripts/axure/adaptive.js"></script>
    <script src="resources/scripts/axure/tree.js"></script>
    <script src="resources/scripts/axure/init.temp.js"></script>
    <script src="resources/scripts/axure/legacy.js"></script>
    <script src="resources/scripts/axure/viewer.js"></script>
    <script src="resources/scripts/axure/math.js"></script>
    <script src="resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="data/document.js"></script>
    <script src="files/registration_page/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
  </head>
  <body>
    <form method="post" action ="">
    <div id="base" class="">

      <!-- Unnamed (Rectangle) -->
      <div id="u55" class="ax_default box_2">
        <div id="u55_div" class=""></div>
        <div id="u55_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Shape) -->
      <div id="u56" class="ax_default icon">
        <img id="u56_img" class="img " src="images/registration_page/u56.svg"/>
        <div id="u56_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Sign Up (Rectangle) -->
      <div id="u57" class="ax_default heading_3" data-label="Sign Up">
        <div id="u57_div" class=""></div>
        <div id="u57_text" class="text ">
          <p><span>Sign Up</span></p>
        </div>
      </div>

      <!-- Unnamed (Group) -->
      <div id="u58" class="ax_default" data-left="563" data-top="113" data-width="218" data-height="17">

        <!-- Already Have An Account (Rectangle) -->
        <div id="u59" class="ax_default label" data-label="Already Have An Account">
          <div id="u59_div" class=""></div>
          <div id="u59_text" class="text ">
            <p><span>Already have an account?</span></p>
          </div>
        </div>

        <!-- Unnamed (Rectangle) -->
        <div id="u60" class="ax_default label">
          <div id="u60_div" class=""></div>
          <div id="u60_text" class="text ">
            <p><span>Sign in</span></p>
          </div>
        </div>
      </div>

      <!-- Unnamed (Line) -->
      <div id="u61" class="ax_default line">
        <img id="u61_img" class="img " src="images/login_page/u34.svg"/>
        <div id="u61_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u62" class="ax_default image">
        <img id="u62_img" class="img " src="images/registration_page/u62.png"/>
        <div id="u62_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Email Label (Rectangle) -->
      <div id="u63" class="ax_default label" data-label="Email Label">
        <div id="u63_div" class=""></div>
        <div id="u63_text" class="text ">
          <p><span>Email </span></p>
        </div>
      </div>

      <!-- Email Input (Text Field) -->
      <div id="u64" class="ax_default text_field" data-label="Email Input">
        <div id="u64_div" class=""></div>
        <input id="u64_input" type="email" name="u64_input" value="" class="u64_input"/>
      </div>

      <!-- Email Error Message (Rectangle) -->
      <div id="u65" class="ax_default label ax_default_hidden" data-label="Email Error Message" style="display:none; visibility: hidden">
        <div id="u65_div" class=""></div>
        <div id="u65_text" class="text ">
          <p><span>Please enter a valid email address</span></p>
        </div>
      </div>

      <!-- Email Label (Rectangle) -->
      <div id="u66" class="ax_default label" data-label="Email Label">
        <div id="u66_div" class=""></div>
        <div id="u66_text" class="text ">
          <p><span>Phone Number </span></p>
        </div>
      </div>

      <!-- Phone Input (Text Field) -->
      <div id="u67" class="ax_default text_field" data-label="Phone Input">
        <div id="u67_div" class=""></div>
        <input id="u67_input" type="tel" name="u67_input" value="" class="u67_input"/>
      </div>

      <!-- Email Error Message (Rectangle) -->
      <div id="u68" class="ax_default label ax_default_hidden" data-label="Email Error Message" style="display:none; visibility: hidden">
        <div id="u68_div" class=""></div>
        <div id="u68_text" class="text ">
          <p><span>Please enter a valid phone number</span></p>
        </div>
      </div>

      <!-- Password Label (Rectangle) -->
      <div id="u69" class="ax_default label" data-label="Password Label">
        <div id="u69_div" class=""></div>
        <div id="u69_text" class="text ">
          <p><span>Password</span></p>
        </div>
      </div>

      <!-- Password Input (Text Field) -->
      <div id="u70" class="ax_default text_field" data-label="Password Input">
        <div id="u70_div" class=""></div>
        <input id="u70_input" type="password" name="u70_input" value="" class="u70_input"/>
      </div>

      <!-- Password Error Message (Rectangle) -->
      <div id="u71" class="ax_default label ax_default_hidden" data-label="Password Error Message" style="display:none; visibility: hidden">
        <div id="u71_div" class=""></div>
        <div id="u71_text" class="text ">
          <p><span>Please enter a valid password</span></p>
        </div>
      </div>

      <!-- Email Label (Rectangle) -->
      <div id="u72" class="ax_default label" data-label="Email Label">
        <div id="u72_div" class=""></div>
        <div id="u72_text" class="text ">
          <p><span>Gender</span></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u73" class="ax_default image">
        <img id="u73_img" class="img " src="images/registration_page/u73.png"/>
        <div id="u73_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Email Input (Text Field) -->
      <div id="u74" class="ax_default text_field" data-label="Email Input">
        <div id="u74_div" class=""></div>
        <input id="u74_input" type="email" name="u74_input" value="" class="u74_input"/>
      </div>

      <!-- Email Error Message (Rectangle) -->
      <div id="u75" class="ax_default label ax_default_hidden" data-label="Email Error Message" style="display:none; visibility: hidden">
        <div id="u75_div" class=""></div>
        <div id="u75_text" class="text ">
          <p><span>Please enter a valid date of birth</span></p>
        </div>
      </div>

      <!-- Gender Input (Droplist) -->
      <div id="u76" class="ax_default droplist" data-label="Gender Input">
        <div id="u76_div" class=""></div>
        <select id="u76_input" name="u76_input" class="u76_input">
          <option class="u76_input_option" selected value="   --Select--">&nbsp;&nbsp; --Select--</option>
          <option class="u76_input_option" value="   Male">&nbsp;&nbsp; Male</option>
          <option class="u76_input_option" value="   Female">&nbsp;&nbsp; Female</option>
          <option class="u76_input_option" value="   Other">&nbsp;&nbsp; Other</option>
        </select>
      </div>

      <!-- Full Name Label (Rectangle) -->
      <div id="u77" class="ax_default label" data-label="Full Name Label">
        <div id="u77_div" class=""></div>
        <div id="u77_text" class="text ">
          <p><span>Full Name</span></p>
        </div>
      </div>

      <!-- Full Name Input (Text Field) -->
      <div id="u78" class="ax_default text_field" data-label="Full Name Input">
        <div id="u78_div" class=""></div>
        <input id="u78_input" type="text" name="u78_input" value="" class="u78_input"/>
      </div>

      <!-- Full Name Error Message (Rectangle) -->
      <div id="u79" class="ax_default label ax_default_hidden" data-label="Full Name Error Message" style="display:none; visibility: hidden">
        <div id="u79_div" class=""></div>
        <div id="u79_text" class="text ">
          <p><span>Please enter your full name</span></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u80" class="ax_default image">
        <img id="u80_img" class="img " src="images/registration_page/u73.png"/>
        <div id="u80_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Sign Up (Group) -->
      <div id="u81" class="ax_default" data-label="Sign Up" data-left="485" data-top="493" data-width="373" data-height="44">

        <!-- Unnamed (Rectangle) -->
        <div id="u82" class="ax_default primary_button1">
          <div id="u82_div" class=""></div>
          <div id="u82_text" class="text ">
            <input id="u82_text" type="submit" value="Sign Up" style="background-color: #301B3F; color:white" class="u82_text"/>
          </div>
        </div>

        <!-- Secure Icon (Shape) -->
        <div id="u83" class="ax_default icon" data-label="Secure Icon">
          <img id="u83_img" class="img " src="images/login_page/secure_icon_u30.svg"/>
          <div id="u83_text" class="text " style="display:none; visibility: hidden">
            <p></p>
          </div>
        </div>
      </div>

      <!-- Confirm Password Label (Rectangle) -->
      <div id="u84" class="ax_default label" data-label="Confirm Password Label">
        <div id="u84_div" class=""></div>
        <div id="u84_text" class="text ">
          <p><span>Confirm Password</span></p>
        </div>
      </div>

      <!-- Confirm Password Input (Text Field) -->
      <div id="u85" class="ax_default text_field" data-label="Confirm Password Input">
        <div id="u85_div" class=""></div>
        <input id="u85_input" type="password" value="" class="u85_input"/>
      </div>

      <!-- Confirm Password Error Message (Rectangle) -->
      <div id="u86" class="ax_default label ax_default_hidden" data-label="Confirm Password Error Message" style="display:none; visibility: hidden">
        <div id="u86_div" class=""></div>
        <div id="u86_text" class="text ">
          <p><span>Passwords must match</span></p>
        </div>
      </div>

      <!-- Sign Up Text (Rectangle) -->
      <div id="u87" class="ax_default label" data-label="Sign Up Text">
        <div id="u87_div" class=""></div>
        <div id="u87_text" class="text ">
          <p><span>By clicking the &quot;Sign Up&quot; button, you are creating an account, and you agree to the Terms of Use.</span></p>
        </div>
      </div>   
    </div>
    <script src="resources/scripts/axure/ios.js"></script>

    <?php
      $email = filter_input(INPUT_POST, 'u64_input');
      $phonenumber = filter_input(INPUT_POST, 'u67_input');
      $password = filter_input(INPUT_POST, 'u70_input');
      $fullname = filter_input(INPUT_POST, 'u78_input');
      $gender = filter_input(INPUT_POST, 'u76_input');



      $host = "localhost";
      $dbusername = "root";
      $dbpassword = "";
      $dbname = "audace_db";
      // Create connection
      $conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);
      if (mysqli_connect_error()){
        echo "Not Connected to DB";
      die('Connect Error ('. mysqli_connect_errno() .') '
      . mysqli_connect_error());
      }
      else{
        
      $sql = "INSERT INTO user_profile (email,phone_number,password,full_name,gender)
      values ('$email','$phonenumber','$password', '$fullname', '$gender')";

      if ($conn->query($sql)){
        
      }
      else{
      echo "Error: ". $sql ."
      ". $conn->error;
      }

      $conn->close();
      }

      ?>
       
  </form>
  </body>
</html>
