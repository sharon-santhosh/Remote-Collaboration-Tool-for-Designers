﻿<!DOCTYPE html>
<html>
  <head>
    <title>Meetings-Designer</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/meetings-designer/styles.css" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="resources/scripts/axure/axQuery.js"></script>
    <script src="resources/scripts/axure/globals.js"></script>
    <script src="resources/scripts/axutils.js"></script>
    <script src="resources/scripts/axure/annotation.js"></script>
    <script src="resources/scripts/axure/axQuery.std.js"></script>
    <script src="resources/scripts/axure/doc.js"></script>
    <script src="resources/scripts/messagecenter.js"></script>
    <script src="resources/scripts/axure/events.js"></script>
    <script src="resources/scripts/axure/recording.js"></script>
    <script src="resources/scripts/axure/action.js"></script>
    <script src="resources/scripts/axure/expr.js"></script>
    <script src="resources/scripts/axure/geometry.js"></script>
    <script src="resources/scripts/axure/flyout.js"></script>
    <script src="resources/scripts/axure/model.js"></script>
    <script src="resources/scripts/axure/repeater.js"></script>
    <script src="resources/scripts/axure/sto.js"></script>
    <script src="resources/scripts/axure/utils.temp.js"></script>
    <script src="resources/scripts/axure/variables.js"></script>
    <script src="resources/scripts/axure/drag.js"></script>
    <script src="resources/scripts/axure/move.js"></script>
    <script src="resources/scripts/axure/visibility.js"></script>
    <script src="resources/scripts/axure/style.js"></script>
    <script src="resources/scripts/axure/adaptive.js"></script>
    <script src="resources/scripts/axure/tree.js"></script>
    <script src="resources/scripts/axure/init.temp.js"></script>
    <script src="resources/scripts/axure/legacy.js"></script>
    <script src="resources/scripts/axure/viewer.js"></script>
    <script src="resources/scripts/axure/math.js"></script>
    <script src="resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="data/document.js"></script>
    <script src="files/meetings-designer/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">

      <!-- Unnamed (Rectangle) -->
      <div id="u545" class="ax_default box_1">
        <div id="u545_div" class=""></div>
        <div id="u545_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u546" class="ax_default image">
        <img id="u546_img" class="img " src="images/meetings-admin/u129.png"/>
        <div id="u546_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u547" class="ax_default paragraph">
        <div id="u547_div" class=""></div>
        <div id="u547_text" class="text ">
          <p><span>MEETINGS</span></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u548" class="ax_default image">
        <img id="u548_img" class="img " src="images/registration_page/u62.png"/>
        <div id="u548_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u549" class="ax_default paragraph">
        <div id="u549_div" class=""></div>
        <div id="u549_text" class="text ">
          <p><span style="color:#DBD8E3;">Connect </span><span style="color:#C31ED7;">Without</span></p><p><span style="color:#C31ED7;">Limits </span><span style="color:#DBD8E3;">With Your </span></p><p><span style="color:#DBD8E3;">Team Mates!</span></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u550" class="ax_default image">
        <img id="u550_img" class="img " src="images/registration_page/u73.png"/>
        <div id="u550_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u551" class="ax_default box_1">
        <div id="u551_div" class=""></div>
        <div id="u551_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Ellipse) -->
      <div id="u552" class="ax_default ellipse">
        <img id="u552_img" class="img " src="images/meetings-admin/u135.svg"/>
        <div id="u552_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Ellipse) -->
      <div id="u553" class="ax_default ellipse">
        <img id="u553_img" class="img " src="images/meetings-admin/u136.svg"/>
        <div id="u553_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Shape) -->
      <div id="u554" class="ax_default icon">
        <img id="u554_img" class="img " src="images/meetings-admin/u137.svg"/>
        <div id="u554_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Shape) -->
      <div id="u555" class="ax_default icon">
        <img id="u555_img" class="img " src="images/meetings-admin/u138.svg"/>
        <div id="u555_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u556" class="ax_default image">
        <img id="u556_img" class="img " src="images/registration_page/u73.png"/>
        <div id="u556_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u557" class="ax_default box_2">
        <div id="u557_div" class=""></div>
        <div id="u557_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u558" class="ax_default box_2">
        <div id="u558_div" class=""></div>
        <div id="u558_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u559" class="ax_default box_2">
        <div id="u559_div" class=""></div>
        <div id="u559_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u560" class="ax_default box_2">
        <div id="u560_div" class=""></div>
        <div id="u560_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u561" class="ax_default image">
        <img id="u561_img" class="img " src="images/meetings-admin/u144.png"/>
        <div id="u561_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u562" class="ax_default box_2">
        <div id="u562_div" class=""></div>
        <div id="u562_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u563" class="ax_default box_3">
        <div id="u563_div" class=""></div>
        <div id="u563_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Conference Rooms (Dynamic Panel) -->
      <div id="u564" class="ax_default" data-label="Conference Rooms">
        <div id="u564_state0" class="panel_state" data-label="State 1" style="">
          <div id="u564_state0_content" class="panel_state_content">

            <!-- Unnamed (Image) -->
            <div id="u565" class="ax_default image">
              <img id="u565_img" class="img " src="images/meetings-admin/u148.svg"/>
              <div id="u565_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Rectangle) -->
            <div id="u566" class="ax_default paragraph">
              <div id="u566_div" class=""></div>
              <div id="u566_text" class="text ">
                <p><span>Conference Rooms</span></p>
              </div>
            </div>

            <!-- Unnamed (Line) -->
            <div id="u567" class="ax_default line">
              <img id="u567_img" class="img " src="images/meetings-admin/u150.svg"/>
              <div id="u567_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Rectangle) -->
            <div id="u568" class="ax_default paragraph">
              <div id="u568_div" class=""></div>
              <div id="u568_text" class="text ">
                <p><span>Adapt your conference rooms to changing needs with HD video and audio, wireless content sharing, and interactive whiteboarding.</span></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Meetings (Dynamic Panel) -->
      <div id="u569" class="ax_default" data-label="Meetings">
        <div id="u569_state0" class="panel_state" data-label="State 1" style="">
          <div id="u569_state0_content" class="panel_state_content">

            <!-- Unnamed (Rectangle) -->
            <div id="u570" class="ax_default paragraph">
              <div id="u570_div" class=""></div>
              <div id="u570_text" class="text ">
                <p><span>Meetings</span></p>
              </div>
            </div>

            <!-- Unnamed (Line) -->
            <div id="u571" class="ax_default line">
              <img id="u571_img" class="img " src="images/meetings-admin/u154.svg"/>
              <div id="u571_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Rectangle) -->
            <div id="u572" class="ax_default paragraph">
              <div id="u572_div" class=""></div>
              <div id="u572_text" class="text ">
                <p><span>Build stronger relationships, supercharge collaboration, and create an engaging meeting experience with HD video and audio.</span></p>
              </div>
            </div>

            <!-- Unnamed (Rectangle) -->
            <div id="u573" class="ax_default box_1">
              <div id="u573_div" class=""></div>
              <div id="u573_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u574" class="ax_default icon">
              <img id="u574_img" class="img " src="images/meetings-admin/u157.svg"/>
              <div id="u574_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Chat (Dynamic Panel) -->
      <div id="u575" class="ax_default" data-label="Chat">
        <div id="u575_state0" class="panel_state" data-label="State 1" style="">
          <div id="u575_state0_content" class="panel_state_content">

            <!-- Unnamed (Image) -->
            <div id="u576" class="ax_default image">
              <img id="u576_img" class="img " src="images/meetings-admin/u159.svg"/>
              <div id="u576_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Rectangle) -->
            <div id="u577" class="ax_default paragraph">
              <div id="u577_div" class=""></div>
              <div id="u577_text" class="text ">
                <p><span>Chat</span></p>
              </div>
            </div>

            <!-- Unnamed (Line) -->
            <div id="u578" class="ax_default line">
              <img id="u578_img" class="img " src="images/meetings-admin/u161.svg"/>
              <div id="u578_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Rectangle) -->
            <div id="u579" class="ax_default paragraph">
              <div id="u579_div" class=""></div>
              <div id="u579_text" class="text ">
                <p><span>Our chat solution simplifies workflows, boosts productivity, and ensures employees can collaborate securely, both internally and externally.</span></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Phone Systems (Dynamic Panel) -->
      <div id="u580" class="ax_default" data-label="Phone Systems">
        <div id="u580_state0" class="panel_state" data-label="State 1" style="">
          <div id="u580_state0_content" class="panel_state_content">

            <!-- Unnamed (Rectangle) -->
            <div id="u581" class="ax_default paragraph">
              <div id="u581_div" class=""></div>
              <div id="u581_text" class="text ">
                <p><span>Phone System</span></p>
              </div>
            </div>

            <!-- Unnamed (Line) -->
            <div id="u582" class="ax_default line">
              <img id="u582_img" class="img " src="images/meetings-admin/u165.svg"/>
              <div id="u582_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Rectangle) -->
            <div id="u583" class="ax_default paragraph">
              <div id="u583_div" class=""></div>
              <div id="u583_text" class="text ">
                <p><span>Power your voice communications with our global cloud phone solution with secure call routing, call queues, SMS, elevate calls to meetings, and more.</span></p>
              </div>
            </div>

            <!-- Unnamed (Image) -->
            <div id="u584" class="ax_default image">
              <img id="u584_img" class="img " src="images/meetings-admin/u167.svg"/>
              <div id="u584_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u585" class="ax_default image">
        <img id="u585_img" class="img " src="images/meetings-admin/u168.svg"/>
        <div id="u585_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Video Webinars (Dynamic Panel) -->
      <div id="u586" class="ax_default" data-label="Video Webinars">
        <div id="u586_state0" class="panel_state" data-label="State 1" style="">
          <div id="u586_state0_content" class="panel_state_content">

            <!-- Unnamed (Rectangle) -->
            <div id="u587" class="ax_default paragraph">
              <div id="u587_div" class=""></div>
              <div id="u587_text" class="text ">
                <p><span>Video Webinars</span></p>
              </div>
            </div>

            <!-- Unnamed (Line) -->
            <div id="u588" class="ax_default line">
              <img id="u588_img" class="img " src="images/meetings-admin/u171.svg"/>
              <div id="u588_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Rectangle) -->
            <div id="u589" class="ax_default paragraph">
              <div id="u589_div" class=""></div>
              <div id="u589_text" class="text ">
                <p><span>Create virtual experiences that attendees will love. Get started today with Zoom Events and Video Webinars.</span></p>
              </div>
            </div>

            <!-- Unnamed (Image) -->
            <div id="u590" class="ax_default image">
              <img id="u590_img" class="img " src="images/meetings-admin/u173.svg"/>
              <div id="u590_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u591" class="ax_default box_1">
        <div id="u591_div" class=""></div>
        <div id="u591_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u592" class="ax_default paragraph">
        <div id="u592_div" class=""></div>
        <div id="u592_text" class="text ">
          <p><span style="text-decoration:underline ;">PERSONAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u593" class="ax_default button">
        <div id="u593_div" class=""></div>
        <div id="u593_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Home</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u594" class="ax_default button">
        <div id="u594_div" class=""></div>
        <div id="u594_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Profile</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u595" class="ax_default button">
        <div id="u595_div" class=""></div>
        <div id="u595_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Meetings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u596" class="ax_default button">
        <div id="u596_div" class=""></div>
        <div id="u596_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Chat</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u597" class="ax_default paragraph">
        <div id="u597_div" class=""></div>
        <div id="u597_text" class="text ">
          <p><span style="text-decoration:underline ;">TEAM</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u598" class="ax_default button">
        <div id="u598_div" class=""></div>
        <div id="u598_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Create a project</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u599" class="ax_default button">
        <div id="u599_div" class=""></div>
        <div id="u599_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Completed projects</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u600" class="ax_default button">
        <div id="u600_div" class=""></div>
        <div id="u600_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Announcements</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u601" class="ax_default button">
        <div id="u601_div" class=""></div>
        <div id="u601_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Groups</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u602" class="ax_default paragraph">
        <div id="u602_div" class=""></div>
        <div id="u602_text" class="text ">
          <p><span style="text-decoration:underline ;">GENERAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u603" class="ax_default button">
        <div id="u603_div" class=""></div>
        <div id="u603_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Settings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u604" class="ax_default button">
        <div id="u604_div" class=""></div>
        <div id="u604_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Help</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u605" class="ax_default button">
        <div id="u605_div" class=""></div>
        <div id="u605_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; FAQs</span></p>
        </div>
      </div>

      <!-- Unnamed (Dynamic Panel) -->
      <div id="u606" class="ax_default">
        <div id="u606_state0" class="panel_state" data-label="State 1" style="">
          <div id="u606_state0_content" class="panel_state_content">

            <!-- Unnamed (Rectangle) -->
            <div id="u607" class="ax_default box_1">
              <div id="u607_div" class=""></div>
              <div id="u607_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Image) -->
            <div id="u608" class="ax_default image">
              <img id="u608_img" class="img " src="images/home_page/u3.png"/>
              <div id="u608_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u609" class="ax_default icon">
              <img id="u609_img" class="img " src="images/homepage-admin/u107.svg"/>
              <div id="u609_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u610" class="ax_default icon">
              <img id="u610_img" class="img " src="images/homepage-admin/u108.svg"/>
              <div id="u610_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u611" class="ax_default icon">
              <img id="u611_img" class="img " src="images/homepage-admin/u109.svg"/>
              <div id="u611_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script src="resources/scripts/axure/ios.js"></script>
  </body>
</html>
