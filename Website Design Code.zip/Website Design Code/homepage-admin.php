﻿<!DOCTYPE html>
<html>
  <head>
    <title>Homepage-Admin</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/homepage-admin/styles.css" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="resources/scripts/axure/axQuery.js"></script>
    <script src="resources/scripts/axure/globals.js"></script>
    <script src="resources/scripts/axutils.js"></script>
    <script src="resources/scripts/axure/annotation.js"></script>
    <script src="resources/scripts/axure/axQuery.std.js"></script>
    <script src="resources/scripts/axure/doc.js"></script>
    <script src="resources/scripts/messagecenter.js"></script>
    <script src="resources/scripts/axure/events.js"></script>
    <script src="resources/scripts/axure/recording.js"></script>
    <script src="resources/scripts/axure/action.js"></script>
    <script src="resources/scripts/axure/expr.js"></script>
    <script src="resources/scripts/axure/geometry.js"></script>
    <script src="resources/scripts/axure/flyout.js"></script>
    <script src="resources/scripts/axure/model.js"></script>
    <script src="resources/scripts/axure/repeater.js"></script>
    <script src="resources/scripts/axure/sto.js"></script>
    <script src="resources/scripts/axure/utils.temp.js"></script>
    <script src="resources/scripts/axure/variables.js"></script>
    <script src="resources/scripts/axure/drag.js"></script>
    <script src="resources/scripts/axure/move.js"></script>
    <script src="resources/scripts/axure/visibility.js"></script>
    <script src="resources/scripts/axure/style.js"></script>
    <script src="resources/scripts/axure/adaptive.js"></script>
    <script src="resources/scripts/axure/tree.js"></script>
    <script src="resources/scripts/axure/init.temp.js"></script>
    <script src="resources/scripts/axure/legacy.js"></script>
    <script src="resources/scripts/axure/viewer.js"></script>
    <script src="resources/scripts/axure/math.js"></script>
    <script src="resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="data/document.js"></script>
    <script src="files/homepage-admin/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">

      <!-- Unnamed (Rectangle) -->
      <div id="u89" class="ax_default box_1">
        <div id="u89_div" class=""></div>
        <div id="u89_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u90" class="ax_default box_2">
        <div id="u90_div" class=""></div>
        <div id="u90_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u91" class="ax_default box_2">
        <div id="u91_div" class=""></div>
        <div id="u91_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u92" class="ax_default box_2">
        <div id="u92_div" class=""></div>
        <div id="u92_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u93" class="ax_default box_2">
        <div id="u93_div" class=""></div>
        <div id="u93_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u94" class="ax_default image">
        <img id="u94_img" class="img " src="images/homepage-admin/u94.png"/>
        <div id="u94_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u95" class="ax_default paragraph">
        <div id="u95_div" class=""></div>
        <div id="u95_text" class="text ">
          <p><span>View and assess new projects done by each team.</span></p>
        </div>
      </div>

      <!-- view_projects_button (Rectangle) -->
      <div id="u96" class="ax_default button" data-label="view_projects_button">
        <div id="u96_div" class=""></div>
        <div id="u96_text" class="text ">
          <p><span>View projects</span></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u97" class="ax_default image">
        <img id="u97_img" class="img " src="images/homepage-admin/u97.png"/>
        <div id="u97_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u98" class="ax_default image">
        <img id="u98_img" class="img " src="images/homepage-admin/u98.png"/>
        <div id="u98_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u99" class="ax_default paragraph">
        <div id="u99_div" class=""></div>
        <div id="u99_text" class="text ">
          <p><span>Create and manage groups.</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u100" class="ax_default button">
        <div id="u100_div" class=""></div>
        <div id="u100_text" class="text ">
          <p><span>Manage groups</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u101" class="ax_default box_2">
        <div id="u101_div" class=""></div>
        <div id="u101_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u102" class="ax_default image">
        <img id="u102_img" class="img " src="images/homepage-admin/u102.svg"/>
        <div id="u102_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u103" class="ax_default paragraph">
        <div id="u103_div" class=""></div>
        <div id="u103_text" class="text ">
          <p><span>WELCOME TO AUDACE !</span></p>
        </div>
      </div>

      <!-- Unnamed (Dynamic Panel) -->
      <div id="u104" class="ax_default">
        <div id="u104_state0" class="panel_state" data-label="State 1" style="">
          <div id="u104_state0_content" class="panel_state_content">

            <!-- Unnamed (Rectangle) -->
            <div id="u105" class="ax_default box_1">
              <div id="u105_div" class=""></div>
              <div id="u105_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Image) -->
            <div id="u106" class="ax_default image">
              <img id="u106_img" class="img " src="images/home_page/u3.png"/>
              <div id="u106_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u107" class="ax_default icon">
              <img id="u107_img" class="img " src="images/homepage-admin/u107.svg"/>
              <div id="u107_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u108" class="ax_default icon">
              <img id="u108_img" class="img " src="images/homepage-admin/u108.svg"/>
              <div id="u108_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u109" class="ax_default icon">
              <img id="u109_img" class="img " src="images/homepage-admin/u109.svg"/>
              <div id="u109_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u110" class="ax_default box_1">
        <div id="u110_div" class=""></div>
        <div id="u110_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u111" class="ax_default paragraph">
        <div id="u111_div" class=""></div>
        <div id="u111_text" class="text ">
          <p><span style="text-decoration:underline ;">PERSONAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u112" class="ax_default button">
        <div id="u112_div" class=""></div>
        <div id="u112_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Home</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u113" class="ax_default button">
        <div id="u113_div" class=""></div>
        <div id="u113_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Profile</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u114" class="ax_default button">
        <div id="u114_div" class=""></div>
        <div id="u114_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Meetings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u115" class="ax_default button">
        <div id="u115_div" class=""></div>
        <div id="u115_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Chat</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u116" class="ax_default paragraph">
        <div id="u116_div" class=""></div>
        <div id="u116_text" class="text ">
          <p><span style="text-decoration:underline ;">ADMIN</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u117" class="ax_default button">
        <div id="u117_div" class=""></div>
        <div id="u117_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; View Projects</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u118" class="ax_default button">
        <div id="u118_div" class=""></div>
        <div id="u118_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Manage Projects</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u119" class="ax_default button">
        <div id="u119_div" class=""></div>
        <div id="u119_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Announcements</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u120" class="ax_default button">
        <div id="u120_div" class=""></div>
        <div id="u120_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Manage Groups</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u121" class="ax_default paragraph">
        <div id="u121_div" class=""></div>
        <div id="u121_text" class="text ">
          <p><span style="text-decoration:underline ;">GENERAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u122" class="ax_default button">
        <div id="u122_div" class=""></div>
        <div id="u122_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Settings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u123" class="ax_default button">
        <div id="u123_div" class=""></div>
        <div id="u123_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Help</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u124" class="ax_default button">
        <div id="u124_div" class=""></div>
        <div id="u124_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; FAQs</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u125" class="ax_default button">
        <div id="u125_div" class=""></div>
        <div id="u125_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Manage Employees</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u126" class="ax_default button">
        <div id="u126_div" class=""></div>
        <div id="u126_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; View Employees</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u127" class="ax_default button">
        <div id="u127_div" class=""></div>
        <div id="u127_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; View Groups</span></p>
        </div>
      </div>
    </div>
    <script src="resources/scripts/axure/ios.js"></script>
  </body>
</html>
