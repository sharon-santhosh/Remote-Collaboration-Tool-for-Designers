﻿<!DOCTYPE html>
<html>
  <head>
    <title>View Groups-Admin</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/view_groups-admin/styles.css" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="resources/scripts/axure/axQuery.js"></script>
    <script src="resources/scripts/axure/globals.js"></script>
    <script src="resources/scripts/axutils.js"></script>
    <script src="resources/scripts/axure/annotation.js"></script>
    <script src="resources/scripts/axure/axQuery.std.js"></script>
    <script src="resources/scripts/axure/doc.js"></script>
    <script src="resources/scripts/messagecenter.js"></script>
    <script src="resources/scripts/axure/events.js"></script>
    <script src="resources/scripts/axure/recording.js"></script>
    <script src="resources/scripts/axure/action.js"></script>
    <script src="resources/scripts/axure/expr.js"></script>
    <script src="resources/scripts/axure/geometry.js"></script>
    <script src="resources/scripts/axure/flyout.js"></script>
    <script src="resources/scripts/axure/model.js"></script>
    <script src="resources/scripts/axure/repeater.js"></script>
    <script src="resources/scripts/axure/sto.js"></script>
    <script src="resources/scripts/axure/utils.temp.js"></script>
    <script src="resources/scripts/axure/variables.js"></script>
    <script src="resources/scripts/axure/drag.js"></script>
    <script src="resources/scripts/axure/move.js"></script>
    <script src="resources/scripts/axure/visibility.js"></script>
    <script src="resources/scripts/axure/style.js"></script>
    <script src="resources/scripts/axure/adaptive.js"></script>
    <script src="resources/scripts/axure/tree.js"></script>
    <script src="resources/scripts/axure/init.temp.js"></script>
    <script src="resources/scripts/axure/legacy.js"></script>
    <script src="resources/scripts/axure/viewer.js"></script>
    <script src="resources/scripts/axure/math.js"></script>
    <script src="resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="data/document.js"></script>
    <script src="files/view_groups-admin/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">

      <!-- Unnamed (Rectangle) -->
      <div id="u414" class="ax_default box_1">
        <div id="u414_div" class=""></div>
        <div id="u414_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u415" class="ax_default image">
        <img id="u415_img" class="img " src="images/meetings-admin/u129.png"/>
        <div id="u415_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u416" class="ax_default paragraph">
        <div id="u416_div" class=""></div>
        <div id="u416_text" class="text ">
          <p><span>VIEW GROUPS</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u417" class="ax_default box_1">
        <div id="u417_div" class=""></div>
        <div id="u417_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u418" class="ax_default paragraph">
        <div id="u418_div" class=""></div>
        <div id="u418_text" class="text ">
          <p><span style="text-decoration:underline ;">PERSONAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u419" class="ax_default button">
        <div id="u419_div" class=""></div>
        <div id="u419_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Home</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u420" class="ax_default button">
        <div id="u420_div" class=""></div>
        <div id="u420_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Profile</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u421" class="ax_default button">
        <div id="u421_div" class=""></div>
        <div id="u421_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Meetings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u422" class="ax_default button">
        <div id="u422_div" class=""></div>
        <div id="u422_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Chat</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u423" class="ax_default paragraph">
        <div id="u423_div" class=""></div>
        <div id="u423_text" class="text ">
          <p><span style="text-decoration:underline ;">ADMIN</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u424" class="ax_default button">
        <div id="u424_div" class=""></div>
        <div id="u424_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; View Projects</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u425" class="ax_default button">
        <div id="u425_div" class=""></div>
        <div id="u425_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Manage Projects</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u426" class="ax_default button">
        <div id="u426_div" class=""></div>
        <div id="u426_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Announcements</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u427" class="ax_default button">
        <div id="u427_div" class=""></div>
        <div id="u427_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Manage Groups</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u428" class="ax_default paragraph">
        <div id="u428_div" class=""></div>
        <div id="u428_text" class="text ">
          <p><span style="text-decoration:underline ;">GENERAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u429" class="ax_default button">
        <div id="u429_div" class=""></div>
        <div id="u429_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Settings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u430" class="ax_default button">
        <div id="u430_div" class=""></div>
        <div id="u430_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Help</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u431" class="ax_default button">
        <div id="u431_div" class=""></div>
        <div id="u431_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; FAQs</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u432" class="ax_default button">
        <div id="u432_div" class=""></div>
        <div id="u432_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Manage Employees</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u433" class="ax_default button">
        <div id="u433_div" class=""></div>
        <div id="u433_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; View Employees</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u434" class="ax_default button">
        <div id="u434_div" class=""></div>
        <div id="u434_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; View Groups</span></p>
        </div>
      </div>

      <!-- Unnamed (Dynamic Panel) -->
      <div id="u435" class="ax_default">
        <div id="u435_state0" class="panel_state" data-label="State 1" style="">
          <div id="u435_state0_content" class="panel_state_content">

            <!-- Unnamed (Rectangle) -->
            <div id="u436" class="ax_default box_1">
              <div id="u436_div" class=""></div>
              <div id="u436_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Image) -->
            <div id="u437" class="ax_default image">
              <img id="u437_img" class="img " src="images/home_page/u3.png"/>
              <div id="u437_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u438" class="ax_default icon">
              <img id="u438_img" class="img " src="images/homepage-admin/u107.svg"/>
              <div id="u438_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u439" class="ax_default icon">
              <img id="u439_img" class="img " src="images/homepage-admin/u108.svg"/>
              <div id="u439_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u440" class="ax_default icon">
              <img id="u440_img" class="img " src="images/homepage-admin/u109.svg"/>
              <div id="u440_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script src="resources/scripts/axure/ios.js"></script>

      <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round|Open+Sans">
      <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
      <style type="text/css">
      .bs-example{
      margin-top: 0px;
      margin-left: 370px;
      text-align: center;
      color:white;
      width:70%;
      height:500px;
      font-size:25px;

      }
      </style>
      <script type="text/javascript">
      $(document).ready(function(){
      $('[data-toggle="tooltip"]').tooltip();   
      });
      </script>
     
      
      <div class="bs-example">
      <div class="container">
      <div class="row">
      <div class="col-md-12">
      <div class="page-header clearfix">
      </div>
      

      <?php
       $host='localhost';
          $username='root';
          $password='';
          $dbname = "audace_db";
          $conn=mysqli_connect($host,$username,$password,$dbname);
          if(!$conn)
              {
                die('Could not Connect MySql Server:' .mysql_error());
              }
      $result = mysqli_query($conn,"SELECT * FROM groups");
      ?>
      <?php
      if (mysqli_num_rows($result) > 0) {
      ?>


      <table class='table table-bordered ' bgcolor= #E2BFDC style="margin-top: 300px;" >


      <tr style="color: white" tr bgcolor=#5A1843>

      <td><b>Group Name</b></td>
      <td><b>Member 1<b></td>
      <td><b>Member 2<b></td>
      </tr>


      <?php
      $i=0;
      while($row = mysqli_fetch_array($result)) {
      ?>
      <tr>
      <td><?php echo $row["group_name"]; ?></td>
      <td><?php echo $row["member_1"]; ?></td>
      <td><?php echo $row["member_2"]; ?></td>
      </tr>
      <?php
      $i++;
      }
      ?>
      </table>
      <?php
      }
      else{
      echo "No result found";
      }
      ?>

  </body>
</html>
