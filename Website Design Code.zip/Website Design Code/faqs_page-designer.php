﻿<!DOCTYPE html>
<html>
  <head>
    <title>FAQs Page-Designer</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/faqs_page-designer/styles.css" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="resources/scripts/axure/axQuery.js"></script>
    <script src="resources/scripts/axure/globals.js"></script>
    <script src="resources/scripts/axutils.js"></script>
    <script src="resources/scripts/axure/annotation.js"></script>
    <script src="resources/scripts/axure/axQuery.std.js"></script>
    <script src="resources/scripts/axure/doc.js"></script>
    <script src="resources/scripts/messagecenter.js"></script>
    <script src="resources/scripts/axure/events.js"></script>
    <script src="resources/scripts/axure/recording.js"></script>
    <script src="resources/scripts/axure/action.js"></script>
    <script src="resources/scripts/axure/expr.js"></script>
    <script src="resources/scripts/axure/geometry.js"></script>
    <script src="resources/scripts/axure/flyout.js"></script>
    <script src="resources/scripts/axure/model.js"></script>
    <script src="resources/scripts/axure/repeater.js"></script>
    <script src="resources/scripts/axure/sto.js"></script>
    <script src="resources/scripts/axure/utils.temp.js"></script>
    <script src="resources/scripts/axure/variables.js"></script>
    <script src="resources/scripts/axure/drag.js"></script>
    <script src="resources/scripts/axure/move.js"></script>
    <script src="resources/scripts/axure/visibility.js"></script>
    <script src="resources/scripts/axure/style.js"></script>
    <script src="resources/scripts/axure/adaptive.js"></script>
    <script src="resources/scripts/axure/tree.js"></script>
    <script src="resources/scripts/axure/init.temp.js"></script>
    <script src="resources/scripts/axure/legacy.js"></script>
    <script src="resources/scripts/axure/viewer.js"></script>
    <script src="resources/scripts/axure/math.js"></script>
    <script src="resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="data/document.js"></script>
    <script src="files/faqs_page-designer/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">

      <!-- Unnamed (Rectangle) -->
      <div id="u756" class="ax_default box_1">
        <div id="u756_div" class=""></div>
        <div id="u756_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u757" class="ax_default box_2">
        <div id="u757_div" class=""></div>
        <div id="u757_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u758" class="ax_default paragraph">
        <div id="u758_div" class=""></div>
        <div id="u758_text" class="text ">
          <p><span>The following are answers to some of the most common questions or problems users come across.</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u759" class="ax_default paragraph">
        <div id="u759_div" class=""></div>
        <div id="u759_text" class="text ">
          <p><span>Can I download Audace on my PC or Mac?</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u760" class="ax_default paragraph">
        <div id="u760_div" class=""></div>
        <div id="u760_text" class="text ">
          <p><span>Audace is a web based collaboration software. It is not available for download on any PC or Mac. However, users can easily login to their account using the website and make use of all the features.</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u761" class="ax_default box_2">
        <div id="u761_div" class=""></div>
        <div id="u761_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u762" class="ax_default paragraph">
        <div id="u762_div" class=""></div>
        <div id="u762_text" class="text ">
          <p><span>Do you need an account to use Audace?</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u763" class="ax_default paragraph">
        <div id="u763_div" class=""></div>
        <div id="u763_text" class="text ">
          <p><span>An Audace account is required to access all the collaboration tools. It allows you to create your own meetings and send invitations to participants. Having an account allows you to create your own instant Meetings or schedule Meetings. An account also allows you to access your personal settings, where you can update your profile or access admin settings depending upon the type of account that you have. </span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u764" class="ax_default box_2">
        <div id="u764_div" class=""></div>
        <div id="u764_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u765" class="ax_default paragraph">
        <div id="u765_div" class=""></div>
        <div id="u765_text" class="text ">
          <p><span>How to I sign up for Audace?</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u766" class="ax_default paragraph">
        <div id="u766_div" class=""></div>
        <div id="u766_text" class="text ">
          <p><span>You can sign up for a free Audace account by clicking the&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; button on the top right corner of the homepage.</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u767" class="ax_default link_button">
        <div id="u767_div" class=""></div>
        <div id="u767_text" class="text ">
          <p><span>Get Started</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u768" class="ax_default box_2">
        <div id="u768_div" class=""></div>
        <div id="u768_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u769" class="ax_default paragraph">
        <div id="u769_div" class=""></div>
        <div id="u769_text" class="text ">
          <p><span>How do I schedule and invite others to my meeting?</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u770" class="ax_default paragraph">
        <div id="u770_div" class=""></div>
        <div id="u770_text" class="text ">
          <p><span>You can schedule a meeting on the web and invite others to join your meeting by copying the join URL or meeting invitation and sending it out via email or other text messengers.</span></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u771" class="ax_default image">
        <img id="u771_img" class="img " src="images/meetings-admin/u129.png"/>
        <div id="u771_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u772" class="ax_default paragraph">
        <div id="u772_div" class=""></div>
        <div id="u772_text" class="text ">
          <p><span>FAQ's</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u773" class="ax_default box_1">
        <div id="u773_div" class=""></div>
        <div id="u773_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u774" class="ax_default paragraph">
        <div id="u774_div" class=""></div>
        <div id="u774_text" class="text ">
          <p><span style="text-decoration:underline ;">PERSONAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u775" class="ax_default button">
        <div id="u775_div" class=""></div>
        <div id="u775_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Home</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u776" class="ax_default button">
        <div id="u776_div" class=""></div>
        <div id="u776_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Profile</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u777" class="ax_default button">
        <div id="u777_div" class=""></div>
        <div id="u777_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Meetings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u778" class="ax_default button">
        <div id="u778_div" class=""></div>
        <div id="u778_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Chat</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u779" class="ax_default paragraph">
        <div id="u779_div" class=""></div>
        <div id="u779_text" class="text ">
          <p><span style="text-decoration:underline ;">TEAM</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u780" class="ax_default button">
        <div id="u780_div" class=""></div>
        <div id="u780_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Create a project</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u781" class="ax_default button">
        <div id="u781_div" class=""></div>
        <div id="u781_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Completed projects</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u782" class="ax_default button">
        <div id="u782_div" class=""></div>
        <div id="u782_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Announcements</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u783" class="ax_default button">
        <div id="u783_div" class=""></div>
        <div id="u783_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Groups</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u784" class="ax_default paragraph">
        <div id="u784_div" class=""></div>
        <div id="u784_text" class="text ">
          <p><span style="text-decoration:underline ;">GENERAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u785" class="ax_default button">
        <div id="u785_div" class=""></div>
        <div id="u785_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Settings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u786" class="ax_default button">
        <div id="u786_div" class=""></div>
        <div id="u786_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Help</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u787" class="ax_default button">
        <div id="u787_div" class=""></div>
        <div id="u787_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; FAQs</span></p>
        </div>
      </div>

      <!-- Unnamed (Dynamic Panel) -->
      <div id="u788" class="ax_default">
        <div id="u788_state0" class="panel_state" data-label="State 1" style="">
          <div id="u788_state0_content" class="panel_state_content">

            <!-- Unnamed (Rectangle) -->
            <div id="u789" class="ax_default box_1">
              <div id="u789_div" class=""></div>
              <div id="u789_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Image) -->
            <div id="u790" class="ax_default image">
              <img id="u790_img" class="img " src="images/home_page/u3.png"/>
              <div id="u790_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u791" class="ax_default icon">
              <img id="u791_img" class="img " src="images/homepage-admin/u107.svg"/>
              <div id="u791_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u792" class="ax_default icon">
              <img id="u792_img" class="img " src="images/homepage-admin/u108.svg"/>
              <div id="u792_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u793" class="ax_default icon">
              <img id="u793_img" class="img " src="images/homepage-admin/u109.svg"/>
              <div id="u793_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script src="resources/scripts/axure/ios.js"></script>
  </body>
</html>
