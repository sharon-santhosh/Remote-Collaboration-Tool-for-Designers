﻿<!DOCTYPE html>
<html>
  <head>
    <title>Manage employees-Admin</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/manage_employees-admin/styles.css" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="resources/scripts/axure/axQuery.js"></script>
    <script src="resources/scripts/axure/globals.js"></script>
    <script src="resources/scripts/axutils.js"></script>
    <script src="resources/scripts/axure/annotation.js"></script>
    <script src="resources/scripts/axure/axQuery.std.js"></script>
    <script src="resources/scripts/axure/doc.js"></script>
    <script src="resources/scripts/messagecenter.js"></script>
    <script src="resources/scripts/axure/events.js"></script>
    <script src="resources/scripts/axure/recording.js"></script>
    <script src="resources/scripts/axure/action.js"></script>
    <script src="resources/scripts/axure/expr.js"></script>
    <script src="resources/scripts/axure/geometry.js"></script>
    <script src="resources/scripts/axure/flyout.js"></script>
    <script src="resources/scripts/axure/model.js"></script>
    <script src="resources/scripts/axure/repeater.js"></script>
    <script src="resources/scripts/axure/sto.js"></script>
    <script src="resources/scripts/axure/utils.temp.js"></script>
    <script src="resources/scripts/axure/variables.js"></script>
    <script src="resources/scripts/axure/drag.js"></script>
    <script src="resources/scripts/axure/move.js"></script>
    <script src="resources/scripts/axure/visibility.js"></script>
    <script src="resources/scripts/axure/style.js"></script>
    <script src="resources/scripts/axure/adaptive.js"></script>
    <script src="resources/scripts/axure/tree.js"></script>
    <script src="resources/scripts/axure/init.temp.js"></script>
    <script src="resources/scripts/axure/legacy.js"></script>
    <script src="resources/scripts/axure/viewer.js"></script>
    <script src="resources/scripts/axure/math.js"></script>
    <script src="resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="data/document.js"></script>
    <script src="files/manage_employees-admin/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
  </head>
  <body>
    <form method="post" action ="">
    <div id="base" class="">

      <!-- Unnamed (Rectangle) -->
      <div id="u336" class="ax_default box_1">
        <div id="u336_div" class=""></div>
        <div id="u336_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u337" class="ax_default image">
        <img id="u337_img" class="img " src="images/manage_employees-admin/u337.png"/>
        <div id="u337_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u338" class="ax_default image">
        <img id="u338_img" class="img " src="images/meetings-admin/u129.png"/>
        <div id="u338_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u339" class="ax_default paragraph">
        <div id="u339_div" class=""></div>
        <div id="u339_text" class="text ">
          <p><span>MANAGE EMPLOYEES</span></p>
        </div>
      </div>

      <!-- Email Error Message (Rectangle) -->
      <div id="u340" class="ax_default label ax_default_hidden" data-label="Email Error Message" style="display:none; visibility: hidden">
        <div id="u340_div" class=""></div>
        <div id="u340_text" class="text ">
          <p><span>Please enter a valid email address</span></p>
        </div>
      </div>

      <!-- Email Label (Rectangle) -->
      <div id="u341" class="ax_default label" data-label="Email Label">
        <div id="u341_div" class=""></div>
        <div id="u341_text" class="text ">
          <p><span>Phone Number </span></p>
        </div>
      </div>

      <!-- Phone Input (Text Field) -->
      <div id="u342" class="ax_default text_field" data-label="Phone Input">
        <div id="u342_div" class=""></div>
        <input id="u342_input" type="tel" name="u342_input" value="" class="u342_input"/>
      </div>

      <!-- Email Error Message (Rectangle) -->
      <div id="u343" class="ax_default label ax_default_hidden" data-label="Email Error Message" style="display:none; visibility: hidden">
        <div id="u343_div" class=""></div>
        <div id="u343_text" class="text ">
          <p><span>Please enter a valid phone number</span></p>
        </div>
      </div>

      <!-- Password Label (Rectangle) -->
      <div id="u344" class="ax_default label" data-label="Password Label">
        <div id="u344_div" class=""></div>
        <div id="u344_text" class="text ">
          <p><span>Password</span></p>
        </div>
      </div>

      <!-- Password Input (Text Field) -->
      <div id="u345" class="ax_default text_field" data-label="Password Input">
        <div id="u345_div" class=""></div>
        <input id="u345_input" type="password" name="u345_input" value="" class="u345_input"/>
      </div>

      <!-- Password Error Message (Rectangle) -->
      <div id="u346" class="ax_default label ax_default_hidden" data-label="Password Error Message" style="display:none; visibility: hidden">
        <div id="u346_div" class=""></div>
        <div id="u346_text" class="text ">
          <p><span>Please enter a valid password</span></p>
        </div>
      </div>

      <!-- Email Label (Rectangle) -->
      <div id="u347" class="ax_default label" data-label="Email Label">
        <div id="u347_div" class=""></div>
        <div id="u347_text" class="text ">
          <p><span>Gender</span></p>
        </div>
      </div>

      <!-- Email Input (Text Field) -->
      <div id="u348" class="ax_default text_field" data-label="Email Input">
        <div id="u348_div" class=""></div>
        <input id="u348_input" type="email" name="u348_input" value="" class="u348_input"/>
      </div>

      <!-- Email Error Message (Rectangle) -->
      <div id="u349" class="ax_default label ax_default_hidden" data-label="Email Error Message" style="display:none; visibility: hidden">
        <div id="u349_div" class=""></div>
        <div id="u349_text" class="text ">
          <p><span>Please enter a valid date of birth</span></p>
        </div>
      </div>

      <!-- Gender Input (Droplist) -->
      <div id="u350" class="ax_default droplist" data-label="Gender Input">
        <div id="u350_div" class=""></div>
        <select id="u350_input" name="u350_input" class="u350_input">
          <option class="u350_input_option" selected value="   --Select--">&nbsp;&nbsp; --Select--</option>
          <option class="u350_input_option" value="   Male">&nbsp;&nbsp; Male</option>
          <option class="u350_input_option" value="   Female">&nbsp;&nbsp; Female</option>
          <option class="u350_input_option" value="   Other">&nbsp;&nbsp; Other</option>
        </select>
      </div>

      <!-- Confirm Password Label (Rectangle) -->
      <div id="u351" class="ax_default label" data-label="Confirm Password Label">
        <div id="u351_div" class=""></div>
        <div id="u351_text" class="text ">
          <p><span>Confirm Password</span></p>
        </div>
      </div>

      <!-- Confirm Password Error Message (Rectangle) -->
      <div id="u352" class="ax_default label ax_default_hidden" data-label="Confirm Password Error Message" style="display:none; visibility: hidden">
        <div id="u352_div" class=""></div>
        <div id="u352_text" class="text ">
          <p><span>Passwords must match</span></p>
        </div>
      </div>

      <!-- Sign Up (Group) -->
      <div id="u353" class="ax_default" data-label="Sign Up" data-left="651" data-top="1001" data-width="373" data-height="44">

        <!-- Unnamed (Rectangle) -->
        <div id="u354" class="ax_default primary_button1">
          <div id="u354_div" class=""></div>
          <div id="u354_text" class="text ">
            <input id="u354_text" type="submit" value="Create Employee" style="background-color: #301B3F; color:white" class="u354_text"/>
          </div>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u355" class="ax_default image">
        <img id="u355_img" class="img " src="images/registration_page/u73.png"/>
        <div id="u355_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Full Name Input (Text Field) -->
      <div id="u356" class="ax_default text_field" data-label="Full Name Input">
        <div id="u356_div" class=""></div>
        <input id="u356_input" type="text" name="u356_input" value="" class="u356_input"/>
      </div>

      <!-- Email Input (Text Field) -->
      <div id="u357" class="ax_default text_field" data-label="Email Input">
        <div id="u357_div" class=""></div>
        <input id="u357_input" type="email" name="u357_input" value="" class="u357_input"/>
      </div>

      <!-- Email Label (Rectangle) -->
      <div id="u358" class="ax_default label" data-label="Email Label">
        <div id="u358_div" class=""></div>
        <div id="u358_text" class="text ">
          <p><span>Email </span></p>
        </div>
      </div>

      <!-- Full Name Label (Rectangle) -->
      <div id="u359" class="ax_default label" data-label="Full Name Label">
        <div id="u359_div" class=""></div>
        <div id="u359_text" class="text ">
          <p><span>Full Name</span></p>
        </div>
      </div>

      <!-- Full Name Error Message (Rectangle) -->
      <div id="u360" class="ax_default label ax_default_hidden" data-label="Full Name Error Message" style="display:none; visibility: hidden">
        <div id="u360_div" class=""></div>
        <div id="u360_text" class="text ">
          <p><span>Please enter your full name</span></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u361" class="ax_default image">
        <img id="u361_img" class="img " src="images/registration_page/u73.png"/>
        <div id="u361_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Confirm Password Input (Text Field) -->
      <div id="u362" class="ax_default text_field" data-label="Confirm Password Input">
        <div id="u362_div" class=""></div>
        <input id="u362_input" type="password" value="" class="u362_input"/>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u363" class="ax_default box_1">
        <div id="u363_div" class=""></div>
        <div id="u363_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u364" class="ax_default paragraph">
        <div id="u364_div" class=""></div>
        <div id="u364_text" class="text ">
          <p><span style="text-decoration:underline ;">PERSONAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u365" class="ax_default button">
        <div id="u365_div" class=""></div>
        <div id="u365_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Home</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u366" class="ax_default button">
        <div id="u366_div" class=""></div>
        <div id="u366_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Profile</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u367" class="ax_default button">
        <div id="u367_div" class=""></div>
        <div id="u367_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Meetings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u368" class="ax_default button">
        <div id="u368_div" class=""></div>
        <div id="u368_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Chat</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u369" class="ax_default paragraph">
        <div id="u369_div" class=""></div>
        <div id="u369_text" class="text ">
          <p><span style="text-decoration:underline ;">ADMIN</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u370" class="ax_default button">
        <div id="u370_div" class=""></div>
        <div id="u370_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; View Projects</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u371" class="ax_default button">
        <div id="u371_div" class=""></div>
        <div id="u371_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Manage Projects</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u372" class="ax_default button">
        <div id="u372_div" class=""></div>
        <div id="u372_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Announcements</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u373" class="ax_default button">
        <div id="u373_div" class=""></div>
        <div id="u373_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Manage Groups</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u374" class="ax_default paragraph">
        <div id="u374_div" class=""></div>
        <div id="u374_text" class="text ">
          <p><span style="text-decoration:underline ;">GENERAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u375" class="ax_default button">
        <div id="u375_div" class=""></div>
        <div id="u375_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Settings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u376" class="ax_default button">
        <div id="u376_div" class=""></div>
        <div id="u376_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Help</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u377" class="ax_default button">
        <div id="u377_div" class=""></div>
        <div id="u377_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; FAQs</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u378" class="ax_default button">
        <div id="u378_div" class=""></div>
        <div id="u378_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Manage Employees</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u379" class="ax_default button">
        <div id="u379_div" class=""></div>
        <div id="u379_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; View Employees</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u380" class="ax_default button">
        <div id="u380_div" class=""></div>
        <div id="u380_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; View Groups</span></p>
        </div>
      </div>

      <!-- Unnamed (Dynamic Panel) -->
      <div id="u381" class="ax_default">
        <div id="u381_state0" class="panel_state" data-label="State 1" style="">
          <div id="u381_state0_content" class="panel_state_content">

            <!-- Unnamed (Rectangle) -->
            <div id="u382" class="ax_default box_1">
              <div id="u382_div" class=""></div>
              <div id="u382_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Image) -->
            <div id="u383" class="ax_default image">
              <img id="u383_img" class="img " src="images/home_page/u3.png"/>
              <div id="u383_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u384" class="ax_default icon">
              <img id="u384_img" class="img " src="images/homepage-admin/u107.svg"/>
              <div id="u384_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u385" class="ax_default icon">
              <img id="u385_img" class="img " src="images/homepage-admin/u108.svg"/>
              <div id="u385_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u386" class="ax_default icon">
              <img id="u386_img" class="img " src="images/homepage-admin/u109.svg"/>
              <div id="u386_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script src="resources/scripts/axure/ios.js"></script>

    <?php
      $email = filter_input(INPUT_POST, 'u357_input');
      $phonenumber = filter_input(INPUT_POST, 'u342_input');
      $password = filter_input(INPUT_POST, 'u345_input');
      $fullname = filter_input(INPUT_POST, 'u356_input');
      $gender = filter_input(INPUT_POST, 'u350_input');



      $host = "localhost";
      $dbusername = "root";
      $dbpassword = "";
      $dbname = "audace_db";
      // Create connection
      $conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);
      if (mysqli_connect_error()){
        echo "Not Connected to DB";
      die('Connect Error ('. mysqli_connect_errno() .') '
      . mysqli_connect_error());
      }
      else{
        
      $sql = "INSERT INTO user_profile (email,phone_number,password,full_name,gender)
      values ('$email','$phonenumber','$password', '$fullname', '$gender')";
      if ($conn->query($sql)){
      
      }
      else{
      echo "Error: ". $sql ."
      ". $conn->error;
      }
      $conn->close();
      }
      ?>


  </form>
  </body>
</html>
