﻿<html>
<head>
    <title></title>
</head>
<body>

    <script language="javascript">
        self.location.href = "start.php#g=1";
    </script>

</body>
</html>
