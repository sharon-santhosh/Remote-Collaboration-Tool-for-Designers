﻿<!DOCTYPE html>
<html>
  <head>
    <title>Announcements-Designer</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/announcements-designer/styles.css" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="resources/scripts/axure/axQuery.js"></script>
    <script src="resources/scripts/axure/globals.js"></script>
    <script src="resources/scripts/axutils.js"></script>
    <script src="resources/scripts/axure/annotation.js"></script>
    <script src="resources/scripts/axure/axQuery.std.js"></script>
    <script src="resources/scripts/axure/doc.js"></script>
    <script src="resources/scripts/messagecenter.js"></script>
    <script src="resources/scripts/axure/events.js"></script>
    <script src="resources/scripts/axure/recording.js"></script>
    <script src="resources/scripts/axure/action.js"></script>
    <script src="resources/scripts/axure/expr.js"></script>
    <script src="resources/scripts/axure/geometry.js"></script>
    <script src="resources/scripts/axure/flyout.js"></script>
    <script src="resources/scripts/axure/model.js"></script>
    <script src="resources/scripts/axure/repeater.js"></script>
    <script src="resources/scripts/axure/sto.js"></script>
    <script src="resources/scripts/axure/utils.temp.js"></script>
    <script src="resources/scripts/axure/variables.js"></script>
    <script src="resources/scripts/axure/drag.js"></script>
    <script src="resources/scripts/axure/move.js"></script>
    <script src="resources/scripts/axure/visibility.js"></script>
    <script src="resources/scripts/axure/style.js"></script>
    <script src="resources/scripts/axure/adaptive.js"></script>
    <script src="resources/scripts/axure/tree.js"></script>
    <script src="resources/scripts/axure/init.temp.js"></script>
    <script src="resources/scripts/axure/legacy.js"></script>
    <script src="resources/scripts/axure/viewer.js"></script>
    <script src="resources/scripts/axure/math.js"></script>
    <script src="resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="data/document.js"></script>
    <script src="files/announcements-designer/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">

      <!-- Unnamed (Rectangle) -->
      <div id="u708" class="ax_default box_1">
        <div id="u708_div" class=""></div>
        <div id="u708_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u709" class="ax_default image">
        <img id="u709_img" class="img " src="images/meetings-admin/u129.png"/>
        <div id="u709_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u710" class="ax_default paragraph">
        <div id="u710_div" class=""></div>
        <div id="u710_text" class="text ">
          <p><span>ANNOUNCEMENTS</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u711" class="ax_default box_1">
        <div id="u711_div" class=""></div>
        <div id="u711_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u712" class="ax_default paragraph">
        <div id="u712_div" class=""></div>
        <div id="u712_text" class="text ">
          <p><span style="text-decoration:underline ;">PERSONAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u713" class="ax_default button">
        <div id="u713_div" class=""></div>
        <div id="u713_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Home</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u714" class="ax_default button">
        <div id="u714_div" class=""></div>
        <div id="u714_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Profile</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u715" class="ax_default button">
        <div id="u715_div" class=""></div>
        <div id="u715_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Meetings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u716" class="ax_default button">
        <div id="u716_div" class=""></div>
        <div id="u716_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Chat</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u717" class="ax_default paragraph">
        <div id="u717_div" class=""></div>
        <div id="u717_text" class="text ">
          <p><span style="text-decoration:underline ;">TEAM</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u718" class="ax_default button">
        <div id="u718_div" class=""></div>
        <div id="u718_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Create a project</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u719" class="ax_default button">
        <div id="u719_div" class=""></div>
        <div id="u719_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Completed projects</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u720" class="ax_default button">
        <div id="u720_div" class=""></div>
        <div id="u720_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Announcements</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u721" class="ax_default button">
        <div id="u721_div" class=""></div>
        <div id="u721_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Groups</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u722" class="ax_default paragraph">
        <div id="u722_div" class=""></div>
        <div id="u722_text" class="text ">
          <p><span style="text-decoration:underline ;">GENERAL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u723" class="ax_default button">
        <div id="u723_div" class=""></div>
        <div id="u723_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Settings</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u724" class="ax_default button">
        <div id="u724_div" class=""></div>
        <div id="u724_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Help</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u725" class="ax_default button">
        <div id="u725_div" class=""></div>
        <div id="u725_text" class="text ">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; FAQs</span></p>
        </div>
      </div>

      <!-- Unnamed (Dynamic Panel) -->
      <div id="u726" class="ax_default">
        <div id="u726_state0" class="panel_state" data-label="State 1" style="">
          <div id="u726_state0_content" class="panel_state_content">

            <!-- Unnamed (Rectangle) -->
            <div id="u727" class="ax_default box_1">
              <div id="u727_div" class=""></div>
              <div id="u727_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Image) -->
            <div id="u728" class="ax_default image">
              <img id="u728_img" class="img " src="images/home_page/u3.png"/>
              <div id="u728_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u729" class="ax_default icon">
              <img id="u729_img" class="img " src="images/homepage-admin/u107.svg"/>
              <div id="u729_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u730" class="ax_default icon">
              <img id="u730_img" class="img " src="images/homepage-admin/u108.svg"/>
              <div id="u730_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Shape) -->
            <div id="u731" class="ax_default icon">
              <img id="u731_img" class="img " src="images/homepage-admin/u109.svg"/>
              <div id="u731_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script src="resources/scripts/axure/ios.js"></script>

      <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round|Open+Sans">
      <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
      <style type="text/css">
      .bs-example{
      margin-top: 0px;
      margin-left: 370px;
      text-align: center;
      color:white;
      width:70%;
      height:500px;
      font-size:20px;

      }
      </style>
      <script type="text/javascript">
      $(document).ready(function(){
      $('[data-toggle="tooltip"]').tooltip();   
      });
      </script>
     
      
      <div class="bs-example">
      <div class="container">
      <div class="row">
      <div class="col-md-12">
      <div class="page-header clearfix">
      </div>
      

      <?php
       $host='localhost';
          $username='root';
          $password='';
          $dbname = "audace_db";
          $conn=mysqli_connect($host,$username,$password,$dbname);
          if(!$conn)
              {
                die('Could not Connect MySql Server:' .mysql_error());
              }
      $result = mysqli_query($conn,"SELECT * FROM announcements");
      ?>
      <?php
      if (mysqli_num_rows($result) > 0) {
      ?>


      <table class='table table-bordered' bgcolor= #E2BFDC style= "margin-top: 300px;" >


      <tr style="color: white" tr bgcolor=#5A1843 >

      <td><b>Title</b></td>
      <td><b>Description<b></td>
      </tr>


      <?php
      $i=0;
      while($row = mysqli_fetch_array($result)) {
      ?>
      <tr>
      <td><?php echo $row["title"]; ?></td>
      <td><?php echo $row["description"]; ?></td>

      </tr>
      <?php
      $i++;
      }
      ?>
      </table>
      <?php
      }
      else{
      echo "No result found";
      }
      ?>

  </body>
</html>
