﻿<!DOCTYPE html>
<html>
  <head>
    <title>Home Page</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/home_page/styles.css" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-3.2.1.min.js"></script>
    <script src="resources/scripts/axure/axQuery.js"></script>
    <script src="resources/scripts/axure/globals.js"></script>
    <script src="resources/scripts/axutils.js"></script>
    <script src="resources/scripts/axure/annotation.js"></script>
    <script src="resources/scripts/axure/axQuery.std.js"></script>
    <script src="resources/scripts/axure/doc.js"></script>
    <script src="resources/scripts/messagecenter.js"></script>
    <script src="resources/scripts/axure/events.js"></script>
    <script src="resources/scripts/axure/recording.js"></script>
    <script src="resources/scripts/axure/action.js"></script>
    <script src="resources/scripts/axure/expr.js"></script>
    <script src="resources/scripts/axure/geometry.js"></script>
    <script src="resources/scripts/axure/flyout.js"></script>
    <script src="resources/scripts/axure/model.js"></script>
    <script src="resources/scripts/axure/repeater.js"></script>
    <script src="resources/scripts/axure/sto.js"></script>
    <script src="resources/scripts/axure/utils.temp.js"></script>
    <script src="resources/scripts/axure/variables.js"></script>
    <script src="resources/scripts/axure/drag.js"></script>
    <script src="resources/scripts/axure/move.js"></script>
    <script src="resources/scripts/axure/visibility.js"></script>
    <script src="resources/scripts/axure/style.js"></script>
    <script src="resources/scripts/axure/adaptive.js"></script>
    <script src="resources/scripts/axure/tree.js"></script>
    <script src="resources/scripts/axure/init.temp.js"></script>
    <script src="resources/scripts/axure/legacy.js"></script>
    <script src="resources/scripts/axure/viewer.js"></script>
    <script src="resources/scripts/axure/math.js"></script>
    <script src="resources/scripts/axure/jquery.nicescroll.min.js"></script>
    <script src="data/document.js"></script>
    <script src="files/home_page/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
  </head>
  <body>
    <div id="base" class="">

      <!-- Unnamed (Rectangle) -->
      <div id="u0" class="ax_default box_2">
        <div id="u0_div" class=""></div>
        <div id="u0_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Dynamic Panel) -->
      <div id="u1" class="ax_default">
        <div id="u1_state0" class="panel_state" data-label="State 1" style="">
          <div id="u1_state0_content" class="panel_state_content">

            <!-- Unnamed (Rectangle) -->
            <div id="u2" class="ax_default box_1">
              <div id="u2_div" class=""></div>
              <div id="u2_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Image) -->
            <div id="u3" class="ax_default image">
              <img id="u3_img" class="img " src="images/home_page/u3.png"/>
              <div id="u3_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>

            <!-- Unnamed (Rectangle) -->
            <div id="u4" class="ax_default button">
              <div id="u4_div" class=""></div>
              <div id="u4_text" class="text ">
                <p><span>Get Started</span></p>
              </div>
            </div>

            <!-- Unnamed (Rectangle) -->
            <div id="u5" class="ax_default paragraph">
              <div id="u5_div" class=""></div>
              <div id="u5_text" class="text ">
                <p><span>Log In </span></p>
              </div>
            </div>

            <!-- Unnamed (Vertical Line) -->
            <div id="u6" class="ax_default line">
              <img id="u6_img" class="img " src="images/home_page/u6.svg"/>
              <div id="u6_text" class="text " style="display:none; visibility: hidden">
                <p></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u7" class="ax_default paragraph">
        <div id="u7_div" class=""></div>
        <div id="u7_text" class="text ">
          <p><span>Alone we can do so little; </span></p><p><span>Together we can do so much.</span></p>
        </div>
      </div>

      <!-- Unnamed (Line) -->
      <div id="u8" class="ax_default line">
        <img id="u8_img" class="img " src="images/home_page/u8.svg"/>
        <div id="u8_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u9" class="ax_default paragraph">
        <div id="u9_div" class=""></div>
        <div id="u9_text" class="text ">
          <p><span>Audace is a collaboration tool for designers that ensures that nothing slips through the gaps and that you never lose great ideas.</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u10" class="ax_default box_2">
        <div id="u10_div" class=""></div>
        <div id="u10_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u11" class="ax_default image">
        <img id="u11_img" class="img " src="images/home_page/u11.svg"/>
        <div id="u11_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u12" class="ax_default paragraph">
        <div id="u12_div" class=""></div>
        <div id="u12_text" class="text ">
          <p><span>Make design changes in real-time</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u13" class="ax_default box_2">
        <div id="u13_div" class=""></div>
        <div id="u13_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u14" class="ax_default paragraph">
        <div id="u14_div" class=""></div>
        <div id="u14_text" class="text ">
          <p><span>Plan, create and organize your designs all in one place</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u15" class="ax_default button">
        <div id="u15_div" class=""></div>
        <div id="u15_text" class="text ">
          <p><span>Get Started</span></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u16" class="ax_default image">
        <img id="u16_img" class="img " src="images/home_page/u16.png"/>
        <div id="u16_text" class="text " style="display:none; visibility: hidden">
          <p></p>
        </div>
      </div>
    </div>
    <script src="resources/scripts/axure/ios.js"></script>
  </body>
</html>
